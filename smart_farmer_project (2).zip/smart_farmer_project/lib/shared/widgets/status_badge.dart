import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class StatusBadge extends StatelessWidget {
  final String status;

  const StatusBadge({Key? key, required this.status}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;

    switch (status.toLowerCase()) {
      case 'accepted':
      case 'low risk':
      case 'operational':
        bg = AppColors.success.withOpacity(0.12);
        fg = AppColors.success;
        break;
      case 'pending':
      case 'medium risk':
      case 'moderate':
        bg = AppColors.warning.withOpacity(0.15);
        fg = Colors.orange.shade800;
        break;
      case 'rejected':
      case 'high risk':
      case 'cancelled':
      case 'poor':
        bg = AppColors.error.withOpacity(0.12);
        fg = AppColors.error;
        break;
      case 'high':
      case 'premium':
        bg = AppColors.primary.withOpacity(0.12);
        fg = AppColors.primary;
        break;
      default:
        bg = Colors.grey.shade200;
        fg = Colors.black87;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: fg.withOpacity(0.3), width: 0.8),
      ),
      child: Text(
        status,
        style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.bold),
      ),
    );
  }
}
