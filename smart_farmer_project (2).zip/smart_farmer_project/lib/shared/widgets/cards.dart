import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../models/crop_model.dart';
import '../../models/market_price_model.dart';
import '../../models/warehouse_model.dart';
import 'status_badge.dart';

class CropCard extends StatelessWidget {
  final CropModel crop;
  final VoidCallback onTap;
  final VoidCallback? onCompare;
  final VoidCallback? onStoragePrediction;

  const CropCard({
    Key? key,
    required this.crop,
    required this.onTap,
    this.onCompare,
    this.onStoragePrediction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.grass_rounded, color: AppColors.primary, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(crop.cropName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          Text('Harvested on ${AppFormatters.formatDate(crop.harvestDate)}',
                              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                        ],
                      ),
                    ],
                  ),
                  StatusBadge(status: crop.quality),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _infoCell('Quantity', '${crop.quantity} ${crop.unit.split(' ').first}'),
                  _infoCell('Condition', crop.condition),
                  _infoCell('Location', crop.farmerLocation.split(',').first),
                ],
              ),
              const Divider(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (onCompare != null)
                    TextButton.icon(
                      onPressed: onCompare,
                      icon: const Icon(Icons.compare_arrows_rounded, size: 18),
                      label: const Text('Compare Markets'),
                    ),
                  if (onStoragePrediction != null)
                    TextButton.icon(
                      onPressed: onStoragePrediction,
                      icon: const Icon(Icons.auto_awesome, size: 18, color: AppColors.primary),
                      label: const Text('AI Storage Check', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoCell(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
      ],
    );
  }
}

class MarketPriceCard extends StatelessWidget {
  final MarketPriceModel market;
  final VoidCallback onTap;
  final bool isSelected;
  final VoidCallback? onSelectionChanged;

  const MarketPriceCard({
    Key? key,
    required this.market,
    required this.onTap,
    this.isSelected = false,
    this.onSelectionChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isSelected ? AppColors.primary : AppColors.divider,
          width: isSelected ? 2.0 : 0.8,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          market.marketName,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${market.city}, ${market.district} • ${market.distanceKm} km away',
                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  if (onSelectionChanged != null)
                    Checkbox(
                      value: isSelected,
                      activeColor: AppColors.primary,
                      onChanged: (val) => onSelectionChanged?.call(),
                    )
                  else
                    StatusBadge(status: '${market.demand} Demand'),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(market.cropName, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 2),
                      Text(
                        AppFormatters.formatCurrency(market.averagePrice),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primary),
                      ),
                      Text(market.priceUnit, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Min: ₹${market.minPrice.toInt()} | Max: ₹${market.maxPrice.toInt()}',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Updated: ${AppFormatters.formatDate(market.lastUpdated)}',
                        style: const TextStyle(color: AppColors.textLight, fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WarehouseCard extends StatelessWidget {
  final WarehouseModel warehouse;
  final VoidCallback onTap;
  final VoidCallback? onEnquire;

  const WarehouseCard({
    Key? key,
    required this.warehouse,
    required this.onTap,
    this.onEnquire,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      warehouse.warehouseName,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                  StatusBadge(status: warehouse.storageType),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                '${warehouse.address} • ${warehouse.distanceKm} km away',
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _metric('Available Space', '${warehouse.availableCapacity.toInt()} Quintals'),
                  _metric('Charges', '₹${warehouse.storageCharges.toInt()} /q/mo'),
                  _metric('Owner', warehouse.ownerName),
                ],
              ),
              const SizedBox(height: 10),
              // Occupancy bar
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: warehouse.totalCapacity > 0 ? (warehouse.occupiedCapacity / warehouse.totalCapacity) : 0,
                  backgroundColor: AppColors.divider,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    warehouse.hasSpace ? AppColors.primary : AppColors.error,
                  ),
                  minHeight: 6,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    warehouse.hasSpace ? 'Space Available' : 'Currently Full',
                    style: TextStyle(
                      color: warehouse.hasSpace ? AppColors.success : AppColors.error,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                  if (onEnquire != null)
                    ElevatedButton(
                      onPressed: warehouse.hasSpace ? onEnquire : null,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        minimumSize: const Size(0, 36),
                      ),
                      child: const Text('Send Enquiry', style: TextStyle(fontSize: 13)),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _metric(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ],
    );
  }
}
