import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../shared/widgets/primary_button.dart';
import '../../state/auth_state.dart';
import '../../state/warehouse_state.dart';

class WarehouseOwnerProfileScreen extends StatelessWidget {
  const WarehouseOwnerProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthState>().currentUser;
    final wh = context.watch<WarehouseState>().currentOwnerWarehouse;

    if (user == null) {
      return const Scaffold(body: Center(child: Text('User not found')));
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Warehouse Owner Profile'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 44,
                    backgroundColor: Colors.deepPurple,
                    child: Text(
                      user.fullName.isNotEmpty ? user.fullName[0].toUpperCase() : 'W',
                      style: const TextStyle(fontSize: 36, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(user.fullName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  Text(user.businessName ?? 'Agro Cold Chain Enterprise', style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _tile(Icons.business, 'Business Name', user.businessName ?? 'Not set'),
                    _tile(Icons.warehouse, 'Facility Name', wh?.warehouseName ?? 'Not set'),
                    _tile(Icons.phone, 'Contact Phone', user.phone),
                    _tile(Icons.email, 'Email Address', user.email),
                    _tile(Icons.map, 'Address', wh?.address ?? 'MIDC Area'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            PrimaryButton(
              label: 'Edit Warehouse Info',
              icon: Icons.edit_outlined,
              onPressed: wh != null ? () => Navigator.pushNamed(context, '/edit_warehouse', arguments: wh) : null,
            ),
            const SizedBox(height: 12),
            SecondaryButton(
              label: 'Settings & Preferences',
              icon: Icons.settings_outlined,
              onPressed: () => Navigator.pushNamed(context, '/settings'),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: () async {
                await context.read<AuthState>().logout();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(context, '/role_selection', (route) => false);
                }
              },
              icon: const Icon(Icons.logout, color: AppColors.error),
              label: const Text('Logout', style: TextStyle(color: AppColors.error, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tile(IconData i, String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(i, size: 20, color: AppColors.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l, style: const TextStyle(fontSize: 11, color: AppColors.textLight)),
                Text(v, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
