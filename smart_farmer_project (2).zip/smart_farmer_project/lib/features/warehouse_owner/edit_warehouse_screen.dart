import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/utils/validators.dart';
import '../../models/warehouse_model.dart';
import '../../shared/widgets/custom_text_field.dart';
import '../../shared/widgets/primary_button.dart';
import '../../state/warehouse_state.dart';

class EditWarehouseScreen extends StatefulWidget {
  final WarehouseModel warehouse;

  const EditWarehouseScreen({Key? key, required this.warehouse}) : super(key: key);

  @override
  State<EditWarehouseScreen> createState() => _EditWarehouseScreenState();
}

class _EditWarehouseScreenState extends State<EditWarehouseScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _addressController;
  late TextEditingController _chargesController;
  late TextEditingController _tempController;
  late TextEditingController _phoneController;
  late String _storageType;
  late String _operationalStatus;

  @override
  void initState() {
    super.initState();
    final w = widget.warehouse;
    _nameController = TextEditingController(text: w.warehouseName);
    _addressController = TextEditingController(text: w.address);
    _chargesController = TextEditingController(text: w.storageCharges.toInt().toString());
    _tempController = TextEditingController(text: w.temperatureRange ?? '');
    _phoneController = TextEditingController(text: w.contactNumber);
    _storageType = w.storageType;
    _operationalStatus = w.operationalStatus ?? 'Operational';
  }

  void _save() async {
    if (_formKey.currentState?.validate() ?? false) {
      final updated = widget.warehouse.copyWith(
        warehouseName: _nameController.text.trim(),
        address: _addressController.text.trim(),
        storageCharges: double.parse(_chargesController.text.trim()),
        temperatureRange: _tempController.text.trim().isEmpty ? null : _tempController.text.trim(),
        contactNumber: _phoneController.text.trim(),
        storageType: _storageType,
        operationalStatus: _operationalStatus,
      );

      final success = await context.read<WarehouseState>().updateWarehouseDetails(updated);
      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Warehouse updated successfully'), backgroundColor: AppColors.success),
        );
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Edit Warehouse Details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: _nameController,
                label: 'Facility Name',
                validator: (v) => AppValidators.validateRequired(v, 'Name'),
              ),
              CustomTextField(
                controller: _addressController,
                label: 'Full Address',
                maxLines: 2,
                validator: (v) => AppValidators.validateRequired(v, 'Address'),
              ),
              CustomTextField(
                controller: _phoneController,
                label: 'Contact Phone Number',
                keyboardType: TextInputType.phone,
                validator: AppValidators.validatePhone,
              ),
              CustomTextField(
                controller: _chargesController,
                label: 'Storage Charges (₹ / quintal / month)',
                keyboardType: TextInputType.number,
                validator: (v) => AppValidators.validatePositiveNumber(v, 'Charges'),
              ),
              CustomTextField(
                controller: _tempController,
                label: 'Temperature / Humidity Range',
                hint: 'e.g. 2°C to 8°C (85% RH)',
              ),
              const Align(alignment: Alignment.centerLeft, child: Text('Storage Type', style: TextStyle(fontWeight: FontWeight.w600))),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _storageType,
                items: const [
                  DropdownMenuItem(value: AppStrings.storageCold, child: Text(AppStrings.storageCold)),
                  DropdownMenuItem(value: AppStrings.storageNormal, child: Text(AppStrings.storageNormal)),
                  DropdownMenuItem(value: AppStrings.storageCA, child: Text(AppStrings.storageCA)),
                  DropdownMenuItem(value: AppStrings.storageDry, child: Text(AppStrings.storageDry)),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _storageType = v);
                },
              ),
              const SizedBox(height: 16),
              const Align(alignment: Alignment.centerLeft, child: Text('Operational Status', style: TextStyle(fontWeight: FontWeight.w600))),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _operationalStatus,
                items: const [
                  DropdownMenuItem(value: 'Operational', child: Text('Operational (Open for intake)')),
                  DropdownMenuItem(value: 'Under Maintenance', child: Text('Under Maintenance')),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _operationalStatus = v);
                },
              ),
              const SizedBox(height: 24),
              PrimaryButton(label: 'Save Changes', onPressed: _save),
            ],
          ),
        ),
      ),
    );
  }
}
