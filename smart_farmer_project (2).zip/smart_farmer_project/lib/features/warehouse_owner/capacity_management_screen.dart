import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/validators.dart';
import '../../shared/widgets/custom_text_field.dart';
import '../../shared/widgets/primary_button.dart';
import '../../state/warehouse_state.dart';

class CapacityManagementScreen extends StatefulWidget {
  const CapacityManagementScreen({Key? key}) : super(key: key);

  @override
  State<CapacityManagementScreen> createState() => _CapacityManagementScreenState();
}

class _CapacityManagementScreenState extends State<CapacityManagementScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _totalController;
  late TextEditingController _availableController;

  @override
  void initState() {
    super.initState();
    final wh = context.read<WarehouseState>().currentOwnerWarehouse;
    _totalController = TextEditingController(text: (wh?.totalCapacity.toInt() ?? 5000).toString());
    _availableController = TextEditingController(text: (wh?.availableCapacity.toInt() ?? 1450).toString());
  }

  void _saveCapacity() async {
    if (_formKey.currentState?.validate() ?? false) {
      final total = double.parse(_totalController.text.trim());
      final available = double.parse(_availableController.text.trim());

      if (available > total) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error: Available capacity cannot exceed total capacity!'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      if (available < 0 || total <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error: Capacity values must be positive!'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      final wh = context.read<WarehouseState>().currentOwnerWarehouse;
      if (wh != null) {
        final updated = wh.copyWith(
          totalCapacity: total,
          availableCapacity: available,
        );
        final success = await context.read<WarehouseState>().updateWarehouseDetails(updated);
        if (success && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Capacity updated successfully'), backgroundColor: AppColors.success),
          );
          Navigator.pop(context);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final wh = context.watch<WarehouseState>().currentOwnerWarehouse;

    final currentTotal = double.tryParse(_totalController.text) ?? (wh?.totalCapacity ?? 5000);
    final currentAvail = double.tryParse(_availableController.text) ?? (wh?.availableCapacity ?? 1450);
    final occupied = (currentTotal - currentAvail).clamp(0.0, currentTotal);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Capacity Management')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Calculated Occupancy Formula', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 6),
                      const Text('Occupied Capacity = Total Capacity − Available Capacity', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _summary('Total', '${currentTotal.toInt()} q'),
                          _summary('Occupied', '${occupied.toInt()} q'),
                          _summary('Available', '${currentAvail.toInt()} q'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              CustomTextField(
                controller: _totalController,
                label: 'Total Facility Capacity (Quintals)',
                keyboardType: TextInputType.number,
                validator: (v) => AppValidators.validatePositiveNumber(v, 'Total Capacity'),
              ),
              CustomTextField(
                controller: _availableController,
                label: 'Available Space for Intake (Quintals)',
                keyboardType: TextInputType.number,
                validator: (v) => AppValidators.validatePositiveNumber(v, 'Available Space'),
              ),
              const SizedBox(height: 24),
              PrimaryButton(
                label: 'Update Capacity Values',
                onPressed: _saveCapacity,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summary(String label, String value) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textLight)),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
      ],
    );
  }
}
