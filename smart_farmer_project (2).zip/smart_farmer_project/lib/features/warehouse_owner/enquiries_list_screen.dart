import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../shared/widgets/status_badge.dart';
import '../../shared/widgets/ui_states.dart';
import '../../state/auth_state.dart';
import '../../state/warehouse_state.dart';

class EnquiriesListScreen extends StatefulWidget {
  const EnquiriesListScreen({Key? key}) : super(key: key);

  @override
  State<EnquiriesListScreen> createState() => _EnquiriesListScreenState();
}

class _EnquiriesListScreenState extends State<EnquiriesListScreen> {
  String _filter = 'All';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<WarehouseState>();
    var list = state.ownerEnquiries;

    if (_filter != 'All') {
      list = list.where((e) => e.status == _filter).toList();
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Farmer Storage Enquiries')),
      body: Column(
        children: [
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ['All', 'Pending', 'Accepted', 'Rejected'].map((status) {
                  final isSelected = _filter == status;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(status),
                      selected: isSelected,
                      selectedColor: AppColors.accent.withOpacity(0.4),
                      onSelected: (val) => setState(() => _filter = status),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? const EmptyStateWidget(
                    title: 'No Enquiries',
                    description: 'No storage requests match the selected status filter.',
                    icon: Icons.inbox_outlined,
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: list.length,
                    itemBuilder: (context, index) {
                      final item = list[index];
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(item.farmerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                  StatusBadge(status: item.status),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text('${item.cropName} • ${item.quantity} ${item.unit} for ${item.durationMonths} Months'),
                              Text('Contact: ${item.farmerContact}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                              const Divider(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    AppFormatters.formatDate(item.createdAt),
                                    style: const TextStyle(color: AppColors.textLight, fontSize: 11),
                                  ),
                                  ElevatedButton(
                                    onPressed: () => Navigator.pushNamed(context, '/enquiry_details', arguments: item),
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                      minimumSize: const Size(0, 32),
                                    ),
                                    child: const Text('Review', style: TextStyle(fontSize: 12)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
