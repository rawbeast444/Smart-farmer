import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../models/storage_request_model.dart';
import '../../shared/widgets/primary_button.dart';
import '../../shared/widgets/status_badge.dart';
import '../../state/auth_state.dart';
import '../../state/warehouse_state.dart';

class EnquiryDetailsScreen extends StatelessWidget {
  final StorageRequestModel enquiry;

  const EnquiryDetailsScreen({Key? key, required this.enquiry}) : super(key: key);

  void _updateStatus(BuildContext context, String newStatus) async {
    final owner = context.read<AuthState>().currentUser;
    if (owner == null) return;

    final success = await context.read<WarehouseState>().updateEnquiryStatus(
      requestId: enquiry.requestId,
      status: newStatus,
      ownerId: owner.uid,
    );

    if (success && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Enquiry marked as $newStatus'),
          backgroundColor: newStatus == 'Accepted' ? AppColors.success : AppColors.error,
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Enquiry Review')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(enquiry.farmerName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primary)),
                        StatusBadge(status: enquiry.status),
                      ],
                    ),
                    const Divider(height: 24),
                    _row('Crop Produce', enquiry.cropName),
                    _row('Quantity', '${enquiry.quantity} ${enquiry.unit}'),
                    _row('Storage Duration', '${enquiry.durationMonths} Months'),
                    _row('Preferred Type', enquiry.preferredStorageType),
                    _row('Farmer Phone', enquiry.farmerContact),
                    _row('Enquiry Date', AppFormatters.formatDate(enquiry.createdAt)),
                    if (enquiry.additionalNotes != null)
                      _row('Farmer Notes', enquiry.additionalNotes!),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            if (enquiry.status == 'Pending') ...[
              PrimaryButton(
                label: 'Accept Storage Request',
                backgroundColor: AppColors.success,
                icon: Icons.check,
                onPressed: () => _updateStatus(context, 'Accepted'),
              ),
              const SizedBox(height: 12),
              SecondaryButton(
                label: 'Reject Request',
                icon: Icons.close,
                onPressed: () => _updateStatus(context, 'Rejected'),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.divider),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.info_outline, color: AppColors.textSecondary, size: 20),
                    const SizedBox(width: 8),
                    Text('This enquiry has already been marked as ${enquiry.status}.'),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _row(String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(l, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Flexible(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13), textAlign: TextAlign.right)),
        ],
      ),
    );
  }
}
