import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../shared/widgets/app_bar_widget.dart';
import '../../shared/widgets/demo_banner_widget.dart';
import '../../shared/widgets/status_badge.dart';
import '../../state/auth_state.dart';
import '../../state/warehouse_state.dart';

class WarehouseDashboardScreen extends StatefulWidget {
  const WarehouseDashboardScreen({Key? key}) : super(key: key);

  @override
  State<WarehouseDashboardScreen> createState() => _WarehouseDashboardScreenState();
}

class _WarehouseDashboardScreenState extends State<WarehouseDashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = context.read<AuthState>().currentUser;
      if (user != null) {
        context.read<WarehouseState>().loadOwnerWarehouse(user.uid);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthState>().currentUser;
    final state = context.watch<WarehouseState>();
    final wh = state.currentOwnerWarehouse;
    final enquiries = state.ownerEnquiries;

    final pendingCount = enquiries.where((e) => e.status == 'Pending').length;
    final acceptedCount = enquiries.where((e) => e.status == 'Accepted').length;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: SmartFarmerAppBar(
        title: 'Warehouse Manager',
        onNotificationTap: () => Navigator.pushNamed(context, '/notifications'),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          if (user != null) {
            await context.read<WarehouseState>().loadOwnerWarehouse(user.uid);
          }
        },
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const DemoBannerWidget(text: 'WAREHOUSE OWNER PORTAL – Live Capacity Management'),

              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome, ${user?.fullName ?? 'Owner'}',
                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      wh?.warehouseName ?? user?.businessName ?? 'Facility Management Console',
                      style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // Statistics Grid
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Capacity Overview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _statCard(
                            title: 'Total Capacity',
                            value: '${wh?.totalCapacity.toInt() ?? 5000} q',
                            icon: Icons.pie_chart_outline,
                            color: Colors.blue,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _statCard(
                            title: 'Available Space',
                            value: '${wh?.availableCapacity.toInt() ?? 1450} q',
                            icon: Icons.check_circle_outline,
                            color: AppColors.success,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _statCard(
                            title: 'Occupied Space',
                            value: '${wh?.occupiedCapacity.toInt() ?? 3550} q',
                            icon: Icons.inventory_2_outlined,
                            color: Colors.deepPurple,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _statCard(
                            title: 'Pending Enquiries',
                            value: '$pendingCount',
                            icon: Icons.pending_actions,
                            color: Colors.orange.shade800,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Quick Shortcuts
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.pushNamed(context, '/capacity_management'),
                            icon: const Icon(Icons.tune),
                            label: const Text('Update Capacity'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.pushNamed(context, '/enquiries_list'),
                            icon: const Icon(Icons.inbox),
                            label: const Text('View Enquiries'),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Recent Farmer Enquiries
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Recent Farmer Enquiries', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                        TextButton(
                          onPressed: () => Navigator.pushNamed(context, '/enquiries_list'),
                          child: const Text('View All', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                        ),
                      ],
                    ),

                    if (enquiries.isEmpty)
                      const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('No enquiries received yet.')))
                    else
                      ...enquiries.take(3).map((enq) {
                        return Card(
                          child: ListTile(
                            title: Text('${enq.farmerName} • ${enq.cropName}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text('${enq.quantity} ${enq.unit} • Duration: ${enq.durationMonths} Mo'),
                            trailing: StatusBadge(status: enq.status),
                            onTap: () => Navigator.pushNamed(context, '/enquiry_details', arguments: enq),
                          ),
                        );
                      }).toList(),

                    const SizedBox(height: 28),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statCard({required String title, required String value, required IconData icon, required Color color}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500)),
                Icon(icon, color: color, size: 20),
              ],
            ),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}
