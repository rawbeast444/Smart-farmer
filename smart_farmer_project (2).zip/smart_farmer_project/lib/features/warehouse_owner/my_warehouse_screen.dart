import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../shared/widgets/primary_button.dart';
import '../../shared/widgets/status_badge.dart';
import '../../state/warehouse_state.dart';

class MyWarehouseScreen extends StatelessWidget {
  const MyWarehouseScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<WarehouseState>();
    final wh = state.currentOwnerWarehouse;

    if (wh == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Facility Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'Edit Facility',
            onPressed: () => Navigator.pushNamed(context, '/edit_warehouse', arguments: wh),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(wh.warehouseName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primary)),
                        ),
                        StatusBadge(status: wh.storageType),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(wh.address, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                    Text('${wh.district}, ${wh.state}', style: const TextStyle(color: AppColors.textLight, fontSize: 12)),
                    const Divider(height: 24),
                    _row('Operational Status', wh.operationalStatus ?? 'Operational'),
                    _row('Storage Charges', '₹${wh.storageCharges.toInt()} / quintal / month'),
                    _row('Temperature Range', wh.temperatureRange ?? 'Not set'),
                    _row('Registered Owner', wh.ownerName),
                    _row('Contact Phone', wh.contactNumber),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Capacity Management Status', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _col('Total', '${wh.totalCapacity.toInt()} q'),
                        _col('Available', '${wh.availableCapacity.toInt()} q'),
                        _col('Occupied', '${wh.occupiedCapacity.toInt()} q'),
                      ],
                    ),
                    const SizedBox(height: 14),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: wh.totalCapacity > 0 ? (wh.occupiedCapacity / wh.totalCapacity) : 0,
                        backgroundColor: AppColors.divider,
                        valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
                        minHeight: 8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            PrimaryButton(
              label: 'Adjust Available Space',
              icon: Icons.tune,
              onPressed: () => Navigator.pushNamed(context, '/capacity_management'),
            ),
            const SizedBox(height: 12),
            SecondaryButton(
              label: 'Edit Warehouse Information',
              icon: Icons.edit_outlined,
              onPressed: () => Navigator.pushNamed(context, '/edit_warehouse', arguments: wh),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(l, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Text(v, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _col(String l, String v) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(l, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
        Text(v, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primary)),
      ],
    );
  }
}
