import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import 'warehouse_dashboard_screen.dart';
import 'my_warehouse_screen.dart';
import 'enquiries_list_screen.dart';
import 'warehouse_owner_profile_screen.dart';

class WarehouseOwnerMainScreen extends StatefulWidget {
  final int initialTab;

  const WarehouseOwnerMainScreen({Key? key, this.initialTab = 0}) : super(key: key);

  @override
  State<WarehouseOwnerMainScreen> createState() => _WarehouseOwnerMainScreenState();
}

class _WarehouseOwnerMainScreenState extends State<WarehouseOwnerMainScreen> {
  late int _currentIndex;

  final List<Widget> _screens = [
    const WarehouseDashboardScreen(),
    const MyWarehouseScreen(),
    const EnquiriesListScreen(),
    const WarehouseOwnerProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialTab;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_outlined),
            activeIcon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.warehouse_outlined),
            activeIcon: Icon(Icons.warehouse_rounded),
            label: 'My Warehouse',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment_outlined),
            activeIcon: Icon(Icons.assignment_rounded),
            label: 'Enquiries',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
