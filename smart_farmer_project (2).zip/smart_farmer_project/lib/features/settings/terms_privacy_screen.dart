import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class TermsPrivacyScreen extends StatelessWidget {
  const TermsPrivacyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Terms & Privacy Policy')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('Privacy Policy & Farmer Data Protection', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
            SizedBox(height: 10),
            Text(
              'Smart Farmer is committed to protecting the privacy of Indian farmers and warehouse operators. '
              'Your crop inventory, location, and mobile number are used exclusively for discovering mandi prices and connecting with verified storage facilities. '
              'We never sell individual farmer data to third-party commercial marketing entities.',
              style: TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
            ),
            SizedBox(height: 20),
            Text('Agricultural Market Terms of Service', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
            SizedBox(height: 10),
            Text(
              '1. Market prices and transportation net return estimates are provided as decision-support indicators. Actual auction prices are determined by open bidding on mandi auction floors.\n\n'
              '2. Warehouse storage agreements and intake terms are contracts made directly between farmers and accredited warehouse operators.\n\n'
              '3. AI storage duration predictions are estimates based on standard post-harvest conditions and do not constitute warranties.',
              style: TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
