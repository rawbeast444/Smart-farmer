import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Help & Kisan Support')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            color: const Color(0xFFE8F5E9),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: const [
                  Icon(Icons.support_agent, size: 40, color: AppColors.primary),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Toll-Free Kisan Call Centre', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        SizedBox(height: 4),
                        Text('Call 1800-180-1551 (6:00 AM - 10:00 PM)', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('Frequently Asked Questions (FAQ)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: AppColors.primary)),
          const SizedBox(height: 10),
          _faq('How are estimated transportation costs calculated?',
              'Transportation cost is estimated based on distance in kilometres multiplied by standard freight rates (₹2.50 per quintal per km) plus standard unloading handling charges.'),
          _faq('How does the AI Crop Storage assistant make predictions?',
              'The assistant utilizes ICAR/NHB agricultural reference ranges combined with real-world parameters (quality grade, damage condition, elapsed days, and storage temperature) to estimate safe shelf-life without spoilage.'),
          _faq('Are the displayed market prices live government data?',
              'During demonstration mode, prices are labelled DEMO DATA based on representative Maharashtra APMC trading bands. The architecture is prepared for direct live integration with AGMARKNET and e-NAM APIs.'),
        ],
      ),
    );
  }

  Widget _faq(String q, String a) {
    return Card(
      child: ExpansionTile(
        title: Text(q, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Text(a, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.4)),
          ),
        ],
      ),
    );
  }
}
