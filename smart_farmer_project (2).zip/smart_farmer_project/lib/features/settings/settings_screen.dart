import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../state/auth_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _language = 'English';
  bool _pushNotifications = true;
  bool _marketAlerts = true;
  bool _weatherWarnings = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Settings & Preferences')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Language (भाषा / भाषा)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary)),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: ['English', 'मराठी (Marathi - Preview)', 'हिन्दी (Hindi - Preview)'].map((lang) {
                return RadioListTile<String>(
                  title: Text(lang),
                  value: lang.split(' ').first,
                  groupValue: _language,
                  activeColor: AppColors.primary,
                  onChanged: (val) {
                    if (val != null) setState(() => _language = val);
                  },
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 20),
          const Text('Notification Preferences', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary)),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Push Notifications'),
                  subtitle: const Text('Receive realtime enquiry updates'),
                  value: _pushNotifications,
                  activeColor: AppColors.primary,
                  onChanged: (v) => setState(() => _pushNotifications = v),
                ),
                SwitchListTile(
                  title: const Text('Market Price Alerts'),
                  subtitle: const Text('Notices when prices swing in APMCs'),
                  value: _marketAlerts,
                  activeColor: AppColors.primary,
                  onChanged: (v) => setState(() => _marketAlerts = v),
                ),
                SwitchListTile(
                  title: const Text('Weather Forecast Warnings'),
                  subtitle: const Text('Advance harvest rain warnings'),
                  value: _weatherWarnings,
                  activeColor: AppColors.primary,
                  onChanged: (v) => setState(() => _weatherWarnings = v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('About & Legal', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary)),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                ListTile(
                  title: const Text('Help & Kisan Support'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.pushNamed(context, '/help_support'),
                ),
                const Divider(height: 1),
                ListTile(
                  title: const Text('Terms of Service & Privacy Policy'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.pushNamed(context, '/terms_privacy'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () async {
              await context.read<AuthState>().logout();
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(context, '/role_selection', (route) => false);
              }
            },
            child: const Text('Log Out of Account', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
