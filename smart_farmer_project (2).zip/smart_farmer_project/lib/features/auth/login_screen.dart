import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/validators.dart';
import '../../shared/widgets/custom_text_field.dart';
import '../../shared/widgets/primary_button.dart';
import '../../shared/widgets/demo_banner_widget.dart';
import '../../state/auth_state.dart';

class LoginScreen extends StatefulWidget {
  final String? initialRole;

  const LoginScreen({Key? key, this.initialRole}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailPhoneController = TextEditingController();
  final _passwordController = TextEditingController();
  late String _selectedRole;
  bool _obscurePassword = true;

  @override
  void initState() {
    super.initState();
    _selectedRole = widget.initialRole ?? 'farmer';
    _prefillDemo();
  }

  void _prefillDemo() {
    if (_selectedRole == 'farmer') {
      _emailPhoneController.text = '9822012345';
      _passwordController.text = 'farmer123';
    } else {
      _emailPhoneController.text = '9422098765';
      _passwordController.text = 'owner123';
    }
  }

  void _handleLogin() async {
    if (_formKey.currentState?.validate() ?? false) {
      final auth = context.read<AuthState>();
      final success = await auth.login(
        emailOrPhone: _emailPhoneController.text.trim(),
        password: _passwordController.text,
        role: _selectedRole,
      );

      if (success && mounted) {
        if (_selectedRole == 'farmer') {
          Navigator.pushNamedAndRemoveUntil(context, '/farmer_main', (route) => false);
        } else {
          Navigator.pushNamedAndRemoveUntil(context, '/warehouse_main', (route) => false);
        }
      } else if (mounted && auth.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(auth.errorMessage!), backgroundColor: AppColors.error),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Login'),
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const DemoBannerWidget(text: 'DEMO MODE – Tap buttons below to quick login demo accounts'),
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Role selector toggle tabs
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: _roleTab(
                                label: 'Farmer Login',
                                role: 'farmer',
                                isSelected: _selectedRole == 'farmer',
                              ),
                            ),
                            Expanded(
                              child: _roleTab(
                                label: 'Warehouse Login',
                                role: 'warehouse_owner',
                                isSelected: _selectedRole == 'warehouse_owner',
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'Welcome Back, ${_selectedRole == 'farmer' ? 'Farmer' : 'Warehouse Owner'}',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Enter your registered mobile or email to proceed.',
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
                      ),
                      const SizedBox(height: 24),
                      CustomTextField(
                        controller: _emailPhoneController,
                        label: 'Mobile Number or Email',
                        hint: 'e.g. 9822012345 or email@domain.com',
                        prefixIcon: Icons.person_outline,
                        validator: (val) => AppValidators.validateRequired(val, 'Email or Mobile Number'),
                      ),
                      CustomTextField(
                        controller: _passwordController,
                        label: 'Password',
                        hint: 'Enter your password',
                        prefixIcon: Icons.lock_outline,
                        obscureText: _obscurePassword,
                        suffixIcon: IconButton(
                          icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility),
                          onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                        ),
                        validator: AppValidators.validatePassword,
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () => Navigator.pushNamed(context, '/forgot_password'),
                          child: const Text('Forgot Password?', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      PrimaryButton(
                        label: 'Login',
                        isLoading: authState.isLoading,
                        onPressed: _handleLogin,
                      ),
                      const SizedBox(height: 16),
                      // Quick demo login shortcuts
                      Center(
                        child: TextButton.icon(
                          onPressed: () {
                            _prefillDemo();
                            _handleLogin();
                          },
                          icon: const Icon(Icons.flash_on_rounded, color: AppColors.secondary),
                          label: Text(
                            'Quick Demo Login (${_selectedRole == 'farmer' ? 'Rahul Patil' : 'Suresh Shinde'})',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Don't have an account? ", style: TextStyle(color: AppColors.textSecondary)),
                          GestureDetector(
                            onTap: () => Navigator.pushNamed(context, '/register', arguments: _selectedRole),
                            child: const Text('Create Account', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleTab({required String label, required String role, required bool isSelected}) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedRole = role;
          _prefillDemo();
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.surface : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          boxShadow: isSelected
              ? [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 4, spreadRadius: 1)]
              : null,
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected ? AppColors.primary : AppColors.textSecondary,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}
