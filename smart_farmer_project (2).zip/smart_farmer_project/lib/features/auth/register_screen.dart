import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/validators.dart';
import '../../shared/widgets/custom_text_field.dart';
import '../../shared/widgets/primary_button.dart';
import '../../state/auth_state.dart';

class RegisterScreen extends StatefulWidget {
  final String? initialRole;

  const RegisterScreen({Key? key, this.initialRole}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _role;

  // Common controllers
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _villageController = TextEditingController();
  final _pincodeController = TextEditingController();
  String _selectedDistrict = 'Sangli';
  final String _selectedState = 'Maharashtra';

  // Farmer specific
  final _farmNameController = TextEditingController();
  final _experienceController = TextEditingController();
  final List<String> _selectedMainCrops = ['Tomato', 'Soybean'];

  // Warehouse specific
  final _businessNameController = TextEditingController();
  final _warehouseNameController = TextEditingController();
  final _warehouseAddressController = TextEditingController();

  bool _obscurePass = true;

  @override
  void initState() {
    super.initState();
    _role = widget.initialRole ?? 'farmer';
  }

  void _handleRegister() async {
    if (_formKey.currentState?.validate() ?? false) {
      if (_passwordController.text != _confirmPasswordController.text) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Passwords do not match'), backgroundColor: AppColors.error),
        );
        return;
      }

      final auth = context.read<AuthState>();
      final success = await auth.register(
        fullName: _nameController.text.trim(),
        email: _emailController.text.trim(),
        phone: _phoneController.text.trim(),
        password: _passwordController.text,
        role: _role,
        state: _selectedState,
        district: _selectedDistrict,
        village: _villageController.text.trim(),
        pincode: _pincodeController.text.trim(),
        farmName: _role == 'farmer' ? _farmNameController.text.trim() : null,
        farmingExperience: _role == 'farmer' ? _experienceController.text.trim() : null,
        mainCrops: _role == 'farmer' ? _selectedMainCrops : [],
        businessName: _role == 'warehouse_owner' ? _businessNameController.text.trim() : null,
        warehouseName: _role == 'warehouse_owner' ? _warehouseNameController.text.trim() : null,
        warehouseAddress: _role == 'warehouse_owner' ? _warehouseAddressController.text.trim() : null,
      );

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registration successful! Welcome to Smart Farmer.'), backgroundColor: AppColors.success),
        );
        if (_role == 'farmer') {
          Navigator.pushNamedAndRemoveUntil(context, '/farmer_main', (route) => false);
        } else {
          Navigator.pushNamedAndRemoveUntil(context, '/warehouse_main', (route) => false);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Register as ${_role == 'farmer' ? 'Farmer' : 'Warehouse Owner'}'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Personal & Location Details',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary),
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: _nameController,
                  label: 'Full Name',
                  hint: 'e.g. Ramesh More',
                  prefixIcon: Icons.person_outline,
                  validator: (v) => AppValidators.validateRequired(v, 'Full Name'),
                ),
                CustomTextField(
                  controller: _phoneController,
                  label: 'Mobile Number',
                  hint: '10-digit mobile number',
                  keyboardType: TextInputType.phone,
                  prefixIcon: Icons.phone_outlined,
                  validator: AppValidators.validatePhone,
                ),
                CustomTextField(
                  controller: _emailController,
                  label: 'Email Address',
                  hint: 'e.g. ramesh@gmail.com',
                  keyboardType: TextInputType.emailAddress,
                  prefixIcon: Icons.email_outlined,
                  validator: AppValidators.validateEmail,
                ),
                CustomTextField(
                  controller: _passwordController,
                  label: 'Password',
                  hint: 'At least 6 characters',
                  obscureText: _obscurePass,
                  prefixIcon: Icons.lock_outline,
                  validator: AppValidators.validatePassword,
                  suffixIcon: IconButton(
                    icon: Icon(_obscurePass ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _obscurePass = !_obscurePass),
                  ),
                ),
                CustomTextField(
                  controller: _confirmPasswordController,
                  label: 'Confirm Password',
                  hint: 'Re-enter password',
                  obscureText: _obscurePass,
                  prefixIcon: Icons.lock_outline,
                  validator: AppValidators.validatePassword,
                ),
                // District dropdown
                const Text('District (Maharashtra)', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _selectedDistrict,
                  items: AppConstants.maharashtraDistricts.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedDistrict = val);
                  },
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.location_city_outlined, color: AppColors.primary)),
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: _villageController,
                  label: 'Village / Town',
                  hint: 'e.g. Tasgaon',
                  prefixIcon: Icons.home_outlined,
                  validator: (v) => AppValidators.validateRequired(v, 'Village'),
                ),
                CustomTextField(
                  controller: _pincodeController,
                  label: 'PIN Code',
                  hint: '6-digit PIN code',
                  keyboardType: TextInputType.number,
                  prefixIcon: Icons.pin_drop_outlined,
                  validator: AppValidators.validatePincode,
                ),

                const Divider(height: 32),
                if (_role == 'farmer') ...[
                  const Text('Farming Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
                  const SizedBox(height: 16),
                  CustomTextField(
                    controller: _farmNameController,
                    label: 'Farm Name (Optional)',
                    hint: 'e.g. More Agri Farm',
                    prefixIcon: Icons.eco_outlined,
                  ),
                  CustomTextField(
                    controller: _experienceController,
                    label: 'Farming Experience (Optional)',
                    hint: 'e.g. 8 Years',
                    prefixIcon: Icons.timeline_outlined,
                  ),
                  const Text('Main Crops Cultivated', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: AppConstants.supportedCrops.map((crop) {
                      final isSelected = _selectedMainCrops.contains(crop);
                      return FilterChip(
                        label: Text(crop),
                        selected: isSelected,
                        selectedColor: AppColors.accent.withOpacity(0.5),
                        checkmarkColor: AppColors.primary,
                        onSelected: (val) {
                          setState(() {
                            if (val) {
                              _selectedMainCrops.add(crop);
                            } else {
                              _selectedMainCrops.remove(crop);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                ] else ...[
                  const Text('Warehouse Enterprise Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
                  const SizedBox(height: 16),
                  CustomTextField(
                    controller: _businessNameController,
                    label: 'Business Enterprise Name',
                    hint: 'e.g. Kisan Cold Chain Ltd',
                    prefixIcon: Icons.business_outlined,
                    validator: (v) => AppValidators.validateRequired(v, 'Business Name'),
                  ),
                  CustomTextField(
                    controller: _warehouseNameController,
                    label: 'Warehouse / Facility Name',
                    hint: 'e.g. Central Modern Cold Storage',
                    prefixIcon: Icons.warehouse_outlined,
                    validator: (v) => AppValidators.validateRequired(v, 'Warehouse Name'),
                  ),
                  CustomTextField(
                    controller: _warehouseAddressController,
                    label: 'Complete Facility Address',
                    hint: 'Plot no, industrial area or highway',
                    maxLines: 2,
                    prefixIcon: Icons.map_outlined,
                    validator: (v) => AppValidators.validateRequired(v, 'Facility Address'),
                  ),
                ],
                const SizedBox(height: 32),
                PrimaryButton(
                  label: 'Register & Create Account',
                  isLoading: auth.isLoading,
                  onPressed: _handleRegister,
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
