import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/repositories/weather_repository.dart';
import '../../../models/weather_model.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/ui_states.dart';

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({Key? key}) : super(key: key);

  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final WeatherRepository _repository = WeatherRepository();
  WeatherModel? _weather;
  bool _isLoading = true;
  String _selectedDistrict = 'Sangli';

  @override
  void initState() {
    super.initState();
    _fetchWeather();
  }

  void _fetchWeather() async {
    setState(() => _isLoading = true);
    final w = await _repository.getWeather(location: '$_selectedDistrict, Maharashtra');
    setState(() {
      _weather = w;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Agriculture Weather Assistant'),
      ),
      body: _isLoading
          ? const LoadingWidget(message: 'Fetching agricultural weather data...')
          : SingleChildScrollView(
              child: Column(
                children: [
                  const DemoBannerWidget(text: 'DEMO WEATHER – OpenWeatherMap Interface Architecture Ready'),

                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // District selector
                        Row(
                          children: [
                            const Text('District:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: DropdownButtonFormField<String>(
                                value: _selectedDistrict,
                                items: AppConstants.maharashtraDistricts.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() => _selectedDistrict = val);
                                    _fetchWeather();
                                  }
                                },
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // Current Weather Card
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF2E7D32), Color(0xFF1B5E20)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 10, offset: const Offset(0, 4)),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(_weather!.location, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                                      Text(_weather!.condition, style: const TextStyle(color: AppColors.accent, fontSize: 14)),
                                    ],
                                  ),
                                  const Icon(Icons.wb_sunny_rounded, color: Colors.orange, size: 48),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Text('${_weather!.temperature.toStringAsFixed(1)}°C', style: const TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  _weatherMetric('Humidity', '${_weather!.humidity}%', Icons.water_drop_outlined),
                                  _weatherMetric('Rainfall Forecast', '${_weather!.rainfallForecastMm} mm', Icons.grain),
                                  _weatherMetric('Wind Speed', '${_weather!.windSpeedKmh} km/h', Icons.air),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Weather Alert if present
                        if (_weather!.weatherAlert != null) ...[
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF3E0),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.orange.shade300),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    _weather!.weatherAlert!,
                                    style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w600, fontSize: 13),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],

                        // Agriculture-Specific Weather Advice
                        const Text('Farming & Harvest Weather Advice', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                        const SizedBox(height: 10),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: _weather!.agricultureAdvice.map((advice) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Icon(Icons.eco, size: 18, color: AppColors.primary),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(advice, style: const TextStyle(fontSize: 13, height: 1.4)),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        // 5-Day Forecast
                        const Text('5-Day Weather Forecast', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                        const SizedBox(height: 10),
                        Card(
                          child: Column(
                            children: _weather!.forecast.map((f) {
                              return ListTile(
                                leading: SizedBox(
                                  width: 70,
                                  child: Text(f.dayName, style: const TextStyle(fontWeight: FontWeight.bold)),
                                ),
                                title: Text(f.condition, style: const TextStyle(fontSize: 13)),
                                trailing: Text(
                                  '${f.tempMax.toInt()}° / ${f.tempMin.toInt()}°C',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _weatherMetric(String label, String val, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: AppColors.accent, size: 20),
        const SizedBox(height: 4),
        Text(val, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }
}
