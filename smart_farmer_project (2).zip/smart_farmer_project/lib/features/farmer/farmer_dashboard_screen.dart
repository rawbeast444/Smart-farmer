import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/utils/formatters.dart';
import '../../shared/widgets/app_bar_widget.dart';
import '../../shared/widgets/demo_banner_widget.dart';
import '../../shared/widgets/cards.dart';
import '../../state/auth_state.dart';
import '../../state/crop_state.dart';
import '../../state/market_state.dart';
import '../../state/warehouse_state.dart';

class FarmerDashboardScreen extends StatefulWidget {
  const FarmerDashboardScreen({Key? key}) : super(key: key);

  @override
  State<FarmerDashboardScreen> createState() => _FarmerDashboardScreenState();
}

class _FarmerDashboardScreenState extends State<FarmerDashboardScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = context.read<AuthState>().currentUser;
      if (user != null) {
        context.read<CropState>().loadCrops(user.uid);
      }
      context.read<MarketState>().loadMarkets();
      context.read<WarehouseState>().searchWarehouses();
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthState>().currentUser;
    final cropState = context.watch<CropState>();
    final marketState = context.watch<MarketState>();
    final warehouseState = context.watch<WarehouseState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: SmartFarmerAppBar(
        title: 'Smart Farmer',
        onNotificationTap: () => Navigator.pushNamed(context, '/notifications'),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          if (user != null) {
            await context.read<CropState>().loadCrops(user.uid);
          }
          await context.read<MarketState>().loadMarkets();
          await context.read<WarehouseState>().searchWarehouses();
        },
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const DemoBannerWidget(),

              // Welcome Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Good Morning, ${user?.fullName.split(' ').first ?? 'Farmer'}!',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Manage your harvest smarter today.',
                              style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.location_on, color: AppColors.accent, size: 14),
                              const SizedBox(width: 4),
                              Text(
                                '${user?.village ?? 'Tasgaon'}, ${user?.district ?? 'Sangli'}',
                                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    // Search Bar
                    TextField(
                      controller: _searchController,
                      onSubmitted: (query) {
                        if (query.trim().isNotEmpty) {
                          Navigator.pushNamed(context, '/market_search', arguments: query.trim());
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Search crops, markets or warehouses...',
                        prefixIcon: const Icon(Icons.search, color: AppColors.primary),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.arrow_forward_rounded, color: AppColors.primary),
                          onPressed: () {
                            if (_searchController.text.trim().isNotEmpty) {
                              Navigator.pushNamed(context, '/market_search', arguments: _searchController.text.trim());
                            }
                          },
                        ),
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // Quick Action Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _actionTile(
                          icon: Icons.add_circle_outline,
                          label: 'Add Crop',
                          color: const Color(0xFF2E7D32),
                          onTap: () => Navigator.pushNamed(context, '/add_crop'),
                        ),
                        _actionTile(
                          icon: Icons.compare_arrows_rounded,
                          label: 'Compare',
                          color: const Color(0xFF1565C0),
                          onTap: () => Navigator.pushNamed(context, '/market_search'),
                        ),
                        _actionTile(
                          icon: Icons.warehouse_outlined,
                          label: 'Find Storage',
                          color: const Color(0xFFE65100),
                          onTap: () => Navigator.pushNamed(context, '/warehouse_search'),
                        ),
                        _actionTile(
                          icon: Icons.auto_awesome,
                          label: 'AI Predict',
                          color: const Color(0xFF6A1B9A),
                          onTap: () => Navigator.pushNamed(context, '/ai_storage'),
                        ),
                        _actionTile(
                          icon: Icons.cloud_outlined,
                          label: 'Weather',
                          color: const Color(0xFF00838F),
                          onTap: () => Navigator.pushNamed(context, '/weather'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Weather Information Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Card(
                  color: const Color(0xFFE8F5E9),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: const BorderSide(color: Color(0xFFC8E6C9)),
                  ),
                  child: InkWell(
                    onTap: () => Navigator.pushNamed(context, '/weather'),
                    borderRadius: BorderRadius.circular(16),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.wb_sunny_rounded, color: Colors.orange, size: 28),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Sangli: 29.5°C • Partly Cloudy', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                SizedBox(height: 3),
                                Text(
                                  'Humidity: 62% • Advisory: Protect open grain yards from midweek showers.',
                                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right, color: AppColors.textLight),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Today's Market Prices Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text("Today's Market Prices", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                        Text("Nearby Maharashtra APMC Mandis", style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      ],
                    ),
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, '/market_search'),
                      child: const Text('View All', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 8),

              // Horizontal Carousel of Market Price Cards
              SizedBox(
                height: 145,
                child: marketState.markets.isEmpty
                    ? const Center(child: CircularProgressIndicator())
                    : ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: marketState.markets.take(5).length,
                        itemBuilder: (context, index) {
                          final market = marketState.markets[index];
                          return Container(
                            width: 250,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            child: Card(
                              child: InkWell(
                                onTap: () => Navigator.pushNamed(context, '/market_details', arguments: market),
                                borderRadius: BorderRadius.circular(16),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              market.marketName,
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: AppColors.primary.withOpacity(0.1),
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: Text('${market.distanceKm} km', style: const TextStyle(fontSize: 10, color: AppColors.primary, fontWeight: FontWeight.bold)),
                                          ),
                                        ],
                                      ),
                                      Text('${market.cropName} • ${market.demand} Demand', style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                AppFormatters.formatCurrency(market.averagePrice),
                                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary),
                                              ),
                                              const Text('per quintal', style: TextStyle(fontSize: 10, color: AppColors.textLight)),
                                            ],
                                          ),
                                          const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.primary),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),

              const SizedBox(height: 20),

              // My Harvested Crops Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('My Harvested Crops', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, '/my_crops'),
                      child: const Text('Manage', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: cropState.crops.isEmpty
                    ? Card(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            children: [
                              const Text('No crops recorded yet'),
                              const SizedBox(height: 8),
                              ElevatedButton(
                                onPressed: () => Navigator.pushNamed(context, '/add_crop'),
                                child: const Text('Add Your First Crop'),
                              ),
                            ],
                          ),
                        ),
                      )
                    : Column(
                        children: cropState.crops.take(2).map((crop) {
                          return CropCard(
                            crop: crop,
                            onTap: () => Navigator.pushNamed(context, '/crop_details', arguments: crop),
                            onCompare: () {
                              context.read<MarketState>().loadMarkets(crop: crop.cropName);
                              Navigator.pushNamed(context, '/market_search');
                            },
                            onStoragePrediction: () => Navigator.pushNamed(context, '/ai_storage', arguments: crop),
                          );
                        }).toList(),
                      ),
              ),

              const SizedBox(height: 20),

              // Nearby Warehouses Preview
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Nearby Warehouses & Storage', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, '/warehouse_search'),
                      child: const Text('View All', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: warehouseState.warehouses.isEmpty
                    ? const Center(child: CircularProgressIndicator())
                    : Column(
                        children: warehouseState.warehouses.take(2).map((wh) {
                          return WarehouseCard(
                            warehouse: wh,
                            onTap: () => Navigator.pushNamed(context, '/warehouse_details', arguments: wh),
                            onEnquire: () => Navigator.pushNamed(context, '/storage_enquiry', arguments: wh),
                          );
                        }).toList(),
                      ),
              ),

              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }

  Widget _actionTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}
