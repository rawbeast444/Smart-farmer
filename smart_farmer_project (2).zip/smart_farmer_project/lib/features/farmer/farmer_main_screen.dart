import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import 'farmer_dashboard_screen.dart';
import 'markets/market_search_screen.dart';
import 'warehouses/warehouse_search_screen.dart';
import 'ai_assistant/ai_storage_screen.dart';
import 'profile/farmer_profile_screen.dart';

class FarmerMainScreen extends StatefulWidget {
  final int initialTab;

  const FarmerMainScreen({Key? key, this.initialTab = 0}) : super(key: key);

  @override
  State<FarmerMainScreen> createState() => _FarmerMainScreenState();
}

class _FarmerMainScreenState extends State<FarmerMainScreen> {
  late int _currentIndex;

  final List<Widget> _screens = [
    const FarmerDashboardScreen(),
    const MarketSearchScreen(),
    const WarehouseSearchScreen(),
    const AIStorageScreen(),
    const FarmerProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialTab;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.storefront_outlined),
            activeIcon: Icon(Icons.storefront_rounded),
            label: 'Markets',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.warehouse_outlined),
            activeIcon: Icon(Icons.warehouse_rounded),
            label: 'Warehouses',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.auto_awesome_outlined),
            activeIcon: Icon(Icons.auto_awesome_rounded),
            label: 'AI Assistant',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
