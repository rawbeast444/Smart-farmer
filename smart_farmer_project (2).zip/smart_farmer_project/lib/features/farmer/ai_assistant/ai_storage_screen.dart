import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/services/ai_storage_service.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/validators.dart';
import '../../../models/crop_model.dart';
import '../../../shared/widgets/custom_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/crop_state.dart';

class AIStorageScreen extends StatefulWidget {
  final CropModel? preselectedCrop;

  const AIStorageScreen({Key? key, this.preselectedCrop}) : super(key: key);

  @override
  State<AIStorageScreen> createState() => _AIStorageScreenState();
}

class _AIStorageScreenState extends State<AIStorageScreen> {
  final _formKey = GlobalKey<FormState>();

  String _cropName = 'Tomato';
  final _varietyController = TextEditingController(text: 'Abhinav');
  String _quality = AppStrings.qualityGood;
  String _condition = AppStrings.conditionFresh;
  DateTime _harvestDate = DateTime.now().subtract(const Duration(days: 2));
  final _quantityController = TextEditingController(text: '50');
  String _storageType = AppStrings.storageCold;
  double _currentTemp = 12.0; // Celsius
  double _currentHumidity = 85.0; // %
  String _packagingType = 'Aerated Plastic Crates';

  @override
  void initState() {
    super.initState();
    if (widget.preselectedCrop != null) {
      final c = widget.preselectedCrop!;
      _cropName = c.cropName;
      _quality = c.quality;
      _condition = c.condition;
      _harvestDate = c.harvestDate;
      _quantityController.text = c.quantity.toInt().toString();
    }
  }

  void _runPrediction() {
    if (_formKey.currentState?.validate() ?? false) {
      final result = AICropStorageService.predictStorageLife(
        cropName: _cropName,
        variety: _varietyController.text.trim().isEmpty ? null : _varietyController.text.trim(),
        quality: _quality,
        condition: _condition,
        harvestDate: _harvestDate,
        quantity: double.tryParse(_quantityController.text.trim()) ?? 50.0,
        storageType: _storageType,
        currentTemp: _currentTemp,
        currentHumidity: _currentHumidity,
        packagingType: _packagingType,
      );

      Navigator.pushNamed(context, '/ai_prediction_result', arguments: result);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('AI Crop Storage Assistant'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Banner
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.primary.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: const BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.auto_awesome, color: Colors.white, size: 24),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Agricultural AI Prediction Engine',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Understand how long your harvested produce remains viable across cold and ambient storage methods.',
                              style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.3),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
                const Text('Crop Parameters', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
                const SizedBox(height: 12),

                // Crop Name
                const Text('Crop Type', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _cropName,
                  items: AppConstants.supportedCrops.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _cropName = v);
                  },
                ),
                const SizedBox(height: 16),

                CustomTextField(
                  controller: _varietyController,
                  label: 'Crop Variety (Optional)',
                  hint: 'e.g. Abhinav, JS-335, Pusa',
                  prefixIcon: Icons.category_outlined,
                ),

                // Harvest Date
                const Text('Harvest Date', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                InkWell(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _harvestDate,
                      firstDate: DateTime.now().subtract(const Duration(days: 365)),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) setState(() => _harvestDate = picked);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(AppFormatters.formatDate(_harvestDate), style: const TextStyle(fontWeight: FontWeight.w500)),
                        const Icon(Icons.calendar_today, size: 18, color: AppColors.primary),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Quality Grade
                const Text('Harvest Quality Grade', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _quality,
                  items: const [
                    DropdownMenuItem(value: AppStrings.qualityPremium, child: Text('Premium (Uniform, Sorted, No Bruises)')),
                    DropdownMenuItem(value: AppStrings.qualityGood, child: Text('Good (Standard Commercial Quality)')),
                    DropdownMenuItem(value: AppStrings.qualityAverage, child: Text('Average (Mixed Sizes, Minor Blemishes)')),
                    DropdownMenuItem(value: AppStrings.qualityPoor, child: Text('Poor (Softening, Bruised Produce)')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _quality = v);
                  },
                ),
                const SizedBox(height: 16),

                // Condition
                const Text('Physical Condition', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _condition,
                  items: const [
                    DropdownMenuItem(value: AppStrings.conditionFresh, child: Text('Freshly Harvested')),
                    DropdownMenuItem(value: AppStrings.conditionSlightlyDamaged, child: Text('Slightly Damaged')),
                    DropdownMenuItem(value: AppStrings.conditionDamaged, child: Text('Damaged / Cracked Skin')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _condition = v);
                  },
                ),
                const SizedBox(height: 20),

                const Text('Storage Environment', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
                const SizedBox(height: 12),

                // Storage Type
                const Text('Storage Method', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _storageType,
                  items: const [
                    DropdownMenuItem(value: AppStrings.storageCold, child: Text(AppStrings.storageCold)),
                    DropdownMenuItem(value: AppStrings.storageNormal, child: Text(AppStrings.storageNormal)),
                    DropdownMenuItem(value: AppStrings.storageCA, child: Text(AppStrings.storageCA)),
                    DropdownMenuItem(value: AppStrings.storageDry, child: Text(AppStrings.storageDry)),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _storageType = v);
                  },
                ),
                const SizedBox(height: 16),

                // Packaging Type
                const Text('Packaging Container', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _packagingType,
                  items: const [
                    DropdownMenuItem(value: 'Aerated Plastic Crates', child: Text('Aerated Plastic Crates')),
                    DropdownMenuItem(value: 'Jute Gunny Bags', child: Text('Jute Gunny Bags')),
                    DropdownMenuItem(value: 'Ventilated Wooden Boxes', child: Text('Ventilated Wooden Boxes')),
                    DropdownMenuItem(value: 'Airtight Plastic Bags', child: Text('Airtight Plastic Bags (Caution: Condensation)')),
                    DropdownMenuItem(value: 'Open Bulk Heap', child: Text('Open Bulk Floor Heap')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _packagingType = v);
                  },
                ),

                const SizedBox(height: 28),

                PrimaryButton(
                  label: 'Calculate Storage Life & Risk',
                  icon: Icons.auto_awesome,
                  onPressed: _runPrediction,
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
