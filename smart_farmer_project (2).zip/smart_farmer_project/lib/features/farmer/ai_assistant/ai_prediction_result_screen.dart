import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../models/ai_prediction_model.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/primary_button.dart';

class AIPredictionResultScreen extends StatelessWidget {
  final AIPredictionResult result;

  const AIPredictionResultScreen({Key? key, required this.result}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color riskColor;
    if (result.spoilageRisk == 'Low Risk') {
      riskColor = AppColors.success;
    } else if (result.spoilageRisk == 'Medium Risk') {
      riskColor = AppColors.warning;
    } else {
      riskColor = AppColors.error;
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Storage Prediction Results'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Prominent Storage Gauge Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: riskColor.withOpacity(0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(color: riskColor.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(result.cropName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primary)),
                      StatusBadge(status: result.spoilageRisk),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 140,
                        height: 140,
                        child: CircularProgressIndicator(
                          value: (result.remainingStorageDays / result.estimatedStorageDays).clamp(0.0, 1.0),
                          strokeWidth: 12,
                          backgroundColor: AppColors.divider,
                          valueColor: AlwaysStoppedAnimation<Color>(riskColor),
                        ),
                      ),
                      Column(
                        children: [
                          Text(
                            '${result.remainingStorageDays.toInt()}',
                            style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: riskColor),
                          ),
                          const Text('Days Left', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Estimated Max Storage: ~${result.estimatedStorageDays.toInt()} Days (${result.storageType})',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    result.explanation,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.3),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Recommended Conditions Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Recommended Storage Conditions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
                    const SizedBox(height: 12),
                    _conditionRow(Icons.thermostat, 'Optimal Temperature', result.recommendedTemp),
                    _conditionRow(Icons.water_drop, 'Optimal Humidity', result.recommendedHumidity),
                    _conditionRow(Icons.layers, 'Storage Setup', result.recommendedConditions),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Warnings Section
            if (result.warnings.isNotEmpty) ...[
              Card(
                color: const Color(0xFFFFF8E1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: const BorderSide(color: Color(0xFFFFE082)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 22),
                          SizedBox(width: 8),
                          Text('Important Harvest Advisories', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.orange)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      ...result.warnings.map(
                        (w) => Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('• ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                              Expanded(child: Text(w, style: const TextStyle(fontSize: 13, color: Colors.black87, height: 1.3))),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Handling Guidelines
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Post-Harvest Handling Instructions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    ...result.handlingInstructions.map(
                      (h) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.check_circle_outline, size: 16, color: AppColors.primary),
                            const SizedBox(width: 8),
                            Expanded(child: Text(h, style: const TextStyle(fontSize: 13, height: 1.3))),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Disclaimer
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                AppStrings.aiDisclaimer,
                style: TextStyle(fontSize: 11, color: Colors.black54, height: 1.3),
              ),
            ),

            const SizedBox(height: 24),
            PrimaryButton(
              label: 'Find Cold Storage for ${result.cropName}',
              icon: Icons.warehouse_rounded,
              onPressed: () {
                Navigator.pushNamed(context, '/warehouse_search');
              },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _conditionRow(IconData icon, String title, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(height: 2),
                Text(val, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
