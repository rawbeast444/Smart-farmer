import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_strings.dart';
import '../../../shared/widgets/cards.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/ui_states.dart';
import '../../../state/warehouse_state.dart';

class WarehouseSearchScreen extends StatefulWidget {
  const WarehouseSearchScreen({Key? key}) : super(key: key);

  @override
  State<WarehouseSearchScreen> createState() => _WarehouseSearchScreenState();
}

class _WarehouseSearchScreenState extends State<WarehouseSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedDistrict = 'All';
  String _selectedStorageType = 'All';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<WarehouseState>().searchWarehouses();
    });
  }

  void _applyFilter() {
    context.read<WarehouseState>().searchWarehouses(
      district: _selectedDistrict,
      storageType: _selectedStorageType,
      query: _searchController.text.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<WarehouseState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Find Nearby Warehouses'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_outlined),
            tooltip: 'My Enquiries',
            onPressed: () => Navigator.pushNamed(context, '/my_enquiries'),
          ),
        ],
      ),
      body: Column(
        children: [
          const DemoBannerWidget(text: 'DEMO WAREHOUSES – Sangli, Kolhapur, Satara & Pune'),

          // Search & Filter Bar
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  onChanged: (val) => _applyFilter(),
                  decoration: const InputDecoration(
                    hintText: 'Search warehouse by name, area or owner...',
                    prefixIcon: Icon(Icons.search, color: AppColors.primary),
                    contentPadding: EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedDistrict,
                          isExpanded: true,
                          underline: const SizedBox(),
                          items: ['All', ...AppConstants.maharashtraDistricts]
                              .map((d) => DropdownMenuItem(value: d, child: Text(d, style: const TextStyle(fontSize: 12))))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedDistrict = val);
                              _applyFilter();
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedStorageType,
                          isExpanded: true,
                          underline: const SizedBox(),
                          items: [
                            'All',
                            AppStrings.storageCold,
                            AppStrings.storageNormal,
                            AppStrings.storageCA,
                            AppStrings.storageDry,
                          ].map((t) => DropdownMenuItem(value: t, child: Text(t, style: const TextStyle(fontSize: 12)))).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedStorageType = val);
                              _applyFilter();
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          Expanded(
            child: state.isLoading
                ? const LoadingWidget(message: 'Searching accredited warehouses...')
                : state.warehouses.isEmpty
                    ? const EmptyStateWidget(
                        title: 'No Warehouses Found',
                        description: 'Try changing your district or storage type criteria.',
                        icon: Icons.warehouse_outlined,
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(14),
                        itemCount: state.warehouses.length,
                        itemBuilder: (context, index) {
                          final wh = state.warehouses[index];
                          return WarehouseCard(
                            warehouse: wh,
                            onTap: () => Navigator.pushNamed(context, '/warehouse_details', arguments: wh),
                            onEnquire: () => Navigator.pushNamed(context, '/storage_enquiry', arguments: wh),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
