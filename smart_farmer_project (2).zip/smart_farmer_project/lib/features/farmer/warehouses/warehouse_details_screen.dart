import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/formatters.dart';
import '../../../models/warehouse_model.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/primary_button.dart';

class WarehouseDetailsScreen extends StatelessWidget {
  final WarehouseModel warehouse;

  const WarehouseDetailsScreen({Key? key, required this.warehouse}) : super(key: key);

  void _simulateCall(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Calling ${warehouse.ownerName} at ${warehouse.contactNumber}...'),
        backgroundColor: AppColors.primary,
      ),
    );
  }

  void _simulateWhatsApp(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening WhatsApp chat with ${warehouse.contactNumber}...'),
        backgroundColor: const Color(0xFF25D366),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final wh = warehouse;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(wh.warehouseName),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const DemoBannerWidget(text: 'VERIFIED FACILITY – WDRA Accredited (Demo Record)'),

            // Facility Image Banner Placeholder
            Container(
              height: 180,
              width: double.infinity,
              color: const Color(0xFFECEFF1),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  const Icon(Icons.warehouse_rounded, size: 80, color: Color(0xFF90A4AE)),
                  Positioned(
                    bottom: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        wh.operationalStatus ?? 'Operational',
                        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          wh.warehouseName,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primary),
                        ),
                      ),
                      StatusBadge(status: wh.storageType),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(wh.address, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text('${wh.distanceKm} km from your farm location', style: const TextStyle(color: AppColors.textLight, fontSize: 12)),

                  const Divider(height: 28),

                  // Capacity Specs Card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Storage Capacity & Occupancy', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(height: 14),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _stat('Total Capacity', '${wh.totalCapacity.toInt()} Quintals'),
                              _stat('Available Space', '${wh.availableCapacity.toInt()} Quintals'),
                              _stat('Occupied', '${wh.occupancyPercentage.toStringAsFixed(0)}%'),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: wh.totalCapacity > 0 ? (wh.occupiedCapacity / wh.totalCapacity) : 0,
                              minHeight: 8,
                              backgroundColor: AppColors.divider,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                wh.hasSpace ? AppColors.primary : AppColors.error,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            wh.hasSpace ? 'Space currently available for immediate intake' : 'Facility is fully occupied',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: wh.hasSpace ? AppColors.success : AppColors.error,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Storage Specifications & Charges
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Pricing & Conditions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(height: 12),
                          _specRow('Storage Charge', '₹${wh.storageCharges.toInt()} / quintal / month'),
                          _specRow('Temperature Range', wh.temperatureRange ?? 'Ambient Aerated'),
                          _specRow('Facility Owner', wh.ownerName),
                          _specRow('Security & Insurance', '24x7 CCTV, Fire Sprinklers & Stock Insurance Included'),
                          _specRow('Minimum Duration', '1 Month'),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Direct Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _simulateCall(context),
                          icon: const Icon(Icons.phone),
                          label: const Text('Call Owner'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _simulateWhatsApp(context),
                          icon: const Icon(Icons.chat),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF25D366),
                            side: const BorderSide(color: Color(0xFF25D366)),
                          ),
                          label: const Text('WhatsApp'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  PrimaryButton(
                    label: 'Send Storage Enquiry',
                    icon: Icons.send_rounded,
                    onPressed: wh.hasSpace
                        ? () => Navigator.pushNamed(context, '/storage_enquiry', arguments: wh)
                        : null,
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textLight)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.primary)),
      ],
    );
  }

  Widget _specRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Flexible(
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13), textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }
}
