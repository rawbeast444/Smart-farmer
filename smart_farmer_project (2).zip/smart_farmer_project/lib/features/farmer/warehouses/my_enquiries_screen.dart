import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/formatters.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/ui_states.dart';
import '../../../state/auth_state.dart';
import '../../../state/warehouse_state.dart';

class MyEnquiriesScreen extends StatefulWidget {
  const MyEnquiriesScreen({Key? key}) : super(key: key);

  @override
  State<MyEnquiriesScreen> createState() => _MyEnquiriesScreenState();
}

class _MyEnquiriesScreenState extends State<MyEnquiriesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = context.read<AuthState>().currentUser;
      if (user != null) {
        context.read<WarehouseState>().loadFarmerEnquiries(user.uid);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final enquiries = context.watch<WarehouseState>().farmerEnquiries;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Storage Enquiries'),
      ),
      body: enquiries.isEmpty
          ? const EmptyStateWidget(
              title: 'No Enquiries Sent',
              description: 'You have not submitted any warehouse storage requests yet.',
              icon: Icons.assignment_outlined,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: enquiries.length,
              itemBuilder: (context, index) {
                final req = enquiries[index];
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                req.warehouseName,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                            ),
                            StatusBadge(status: req.status),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${req.cropName} • ${req.quantity} ${req.unit} for ${req.durationMonths} Months',
                          style: const TextStyle(fontSize: 14, color: AppColors.textPrimary, fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Storage Type: ${req.preferredStorageType}',
                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                        const Divider(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Submitted on ${AppFormatters.formatDate(req.createdAt)}',
                              style: const TextStyle(color: AppColors.textLight, fontSize: 11),
                            ),
                            if (req.status == 'Accepted')
                              const Text('Confirmed Intake', style: TextStyle(color: AppColors.success, fontWeight: FontWeight.bold, fontSize: 12)),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
