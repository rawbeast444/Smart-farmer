import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/validators.dart';
import '../../../models/warehouse_model.dart';
import '../../../shared/widgets/custom_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/auth_state.dart';
import '../../../state/crop_state.dart';
import '../../../state/warehouse_state.dart';

class StorageEnquiryScreen extends StatefulWidget {
  final WarehouseModel warehouse;

  const StorageEnquiryScreen({Key? key, required this.warehouse}) : super(key: key);

  @override
  State<StorageEnquiryScreen> createState() => _StorageEnquiryScreenState();
}

class _StorageEnquiryScreenState extends State<StorageEnquiryScreen> {
  final _formKey = GlobalKey<FormState>();

  String _selectedCrop = 'Tomato';
  final _quantityController = TextEditingController(text: '40');
  String _selectedUnit = AppStrings.unitQuintal;
  int _durationMonths = 1;
  late String _preferredStorageType;
  final _contactController = TextEditingController();
  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _preferredStorageType = widget.warehouse.storageType;
    final user = context.read<AuthState>().currentUser;
    if (user != null) {
      _contactController.text = user.phone;
    }
    final crops = context.read<CropState>().crops;
    if (crops.isNotEmpty) {
      _selectedCrop = crops.first.cropName;
      _quantityController.text = crops.first.quantity.toInt().toString();
    }
  }

  void _submitEnquiry() async {
    if (_formKey.currentState?.validate() ?? false) {
      final user = context.read<AuthState>().currentUser;
      if (user == null) return;

      final success = await context.read<WarehouseState>().submitEnquiry(
        farmerId: user.uid,
        farmerName: user.fullName,
        farmerContact: _contactController.text.trim(),
        warehouseId: widget.warehouse.warehouseId,
        warehouseOwnerId: widget.warehouse.ownerId,
        warehouseName: widget.warehouse.warehouseName,
        cropName: _selectedCrop,
        quantity: double.parse(_quantityController.text.trim()),
        unit: _selectedUnit,
        durationMonths: _durationMonths,
        preferredStorageType: _preferredStorageType,
        additionalNotes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      );

      if (success && mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: Row(
              children: const [
                Icon(Icons.check_circle, color: AppColors.success),
                SizedBox(width: 8),
                Text('Enquiry Sent'),
              ],
            ),
            content: Text(
              'Your storage request for ${_quantityController.text} $_selectedUnit of $_selectedCrop '
              'has been submitted to ${widget.warehouse.warehouseName}. The owner will contact you shortly.',
            ),
            actions: [
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<WarehouseState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Send Storage Enquiry')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.divider),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.warehouse_rounded, color: AppColors.primary, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.warehouse.warehouseName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            Text('Charges: ₹${widget.warehouse.storageCharges.toInt()} /q/month • Available: ${widget.warehouse.availableCapacity.toInt()} q',
                                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                const Text('Enquiry Specifications', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
                const SizedBox(height: 12),

                const Text('Selected Crop', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _selectedCrop,
                  items: AppConstants.supportedCrops.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _selectedCrop = v);
                  },
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: CustomTextField(
                        controller: _quantityController,
                        label: 'Quantity',
                        hint: 'e.g. 50',
                        keyboardType: TextInputType.number,
                        validator: (v) => AppValidators.validatePositiveNumber(v, 'Quantity'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Unit', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            value: _selectedUnit,
                            items: const [
                              DropdownMenuItem(value: AppStrings.unitQuintal, child: Text('Quintals (q)')),
                              DropdownMenuItem(value: AppStrings.unitKg, child: Text('Kilograms (kg)')),
                              DropdownMenuItem(value: AppStrings.unitTonne, child: Text('Tonnes (t)')),
                            ],
                            onChanged: (v) {
                              if (v != null) setState(() => _selectedUnit = v);
                            },
                          ),
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ],
                ),

                const Text('Storage Duration', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                Row(
                  children: [1, 2, 3, 6].map((m) {
                    final selected = _durationMonths == m;
                    return Expanded(
                      child: Container(
                        margin: const EdgeInsets.only(right: 6),
                        child: OutlinedButton(
                          onPressed: () => setState(() => _durationMonths = m),
                          style: OutlinedButton.styleFrom(
                            backgroundColor: selected ? AppColors.primary : Colors.transparent,
                            foregroundColor: selected ? Colors.white : AppColors.textPrimary,
                            side: BorderSide(color: selected ? AppColors.primary : AppColors.divider),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                          child: Text('$m Mo', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                const Text('Preferred Storage Type', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _preferredStorageType,
                  items: const [
                    DropdownMenuItem(value: AppStrings.storageCold, child: Text(AppStrings.storageCold)),
                    DropdownMenuItem(value: AppStrings.storageNormal, child: Text(AppStrings.storageNormal)),
                    DropdownMenuItem(value: AppStrings.storageCA, child: Text(AppStrings.storageCA)),
                    DropdownMenuItem(value: AppStrings.storageDry, child: Text(AppStrings.storageDry)),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _preferredStorageType = v);
                  },
                ),
                const SizedBox(height: 16),

                CustomTextField(
                  controller: _contactController,
                  label: 'Farmer Contact Mobile',
                  hint: '10-digit mobile number',
                  keyboardType: TextInputType.phone,
                  prefixIcon: Icons.phone_outlined,
                  validator: AppValidators.validatePhone,
                ),

                CustomTextField(
                  controller: _notesController,
                  label: 'Additional Message / Requirements',
                  hint: 'Packaging condition, expected intake date, etc.',
                  maxLines: 2,
                  prefixIcon: Icons.message_outlined,
                ),

                const SizedBox(height: 24),

                PrimaryButton(
                  label: 'Submit Storage Enquiry',
                  isLoading: state.isLoading,
                  onPressed: _submitEnquiry,
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
