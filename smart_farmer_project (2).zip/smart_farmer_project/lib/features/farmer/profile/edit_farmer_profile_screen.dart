import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/validators.dart';
import '../../../shared/widgets/custom_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/auth_state.dart';

class EditFarmerProfileScreen extends StatefulWidget {
  const EditFarmerProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditFarmerProfileScreen> createState() => _EditFarmerProfileScreenState();
}

class _EditFarmerProfileScreenState extends State<EditFarmerProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _phoneController;
  late TextEditingController _villageController;
  late TextEditingController _pincodeController;
  late TextEditingController _farmNameController;
  late TextEditingController _experienceController;
  late String _district;

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthState>().currentUser;
    _nameController = TextEditingController(text: user?.fullName ?? '');
    _phoneController = TextEditingController(text: user?.phone ?? '');
    _villageController = TextEditingController(text: user?.village ?? '');
    _pincodeController = TextEditingController(text: user?.pincode ?? '');
    _farmNameController = TextEditingController(text: user?.farmName ?? '');
    _experienceController = TextEditingController(text: user?.farmingExperience ?? '');
    _district = user?.district ?? 'Sangli';
  }

  void _save() async {
    if (_formKey.currentState?.validate() ?? false) {
      final auth = context.read<AuthState>();
      final curr = auth.currentUser;
      if (curr != null) {
        final updated = curr.copyWith(
          fullName: _nameController.text.trim(),
          phone: _phoneController.text.trim(),
          village: _villageController.text.trim(),
          pincode: _pincodeController.text.trim(),
          district: _district,
          farmName: _farmNameController.text.trim(),
          farmingExperience: _experienceController.text.trim(),
        );
        await auth.updateProfile(updated);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile updated successfully'), backgroundColor: AppColors.success),
          );
          Navigator.pop(context);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Edit Farmer Profile')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: _nameController,
                label: 'Full Name',
                validator: (v) => AppValidators.validateRequired(v, 'Name'),
              ),
              CustomTextField(
                controller: _phoneController,
                label: 'Mobile Number',
                keyboardType: TextInputType.phone,
                validator: AppValidators.validatePhone,
              ),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('District', style: TextStyle(fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _district,
                items: AppConstants.maharashtraDistricts.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _district = v);
                },
              ),
              const SizedBox(height: 16),
              CustomTextField(
                controller: _villageController,
                label: 'Village',
                validator: (v) => AppValidators.validateRequired(v, 'Village'),
              ),
              CustomTextField(
                controller: _pincodeController,
                label: 'PIN Code',
                keyboardType: TextInputType.number,
                validator: AppValidators.validatePincode,
              ),
              CustomTextField(
                controller: _farmNameController,
                label: 'Farm Name',
              ),
              CustomTextField(
                controller: _experienceController,
                label: 'Farming Experience',
              ),
              const SizedBox(height: 24),
              PrimaryButton(label: 'Save Changes', onPressed: _save),
            ],
          ),
        ),
      ),
    );
  }
}
