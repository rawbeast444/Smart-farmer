import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/formatters.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/auth_state.dart';

class FarmerProfileScreen extends StatelessWidget {
  const FarmerProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthState>().currentUser;

    if (user == null) {
      return const Scaffold(body: Center(child: Text('User not found')));
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Farmer Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // User Avatar Card
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 44,
                    backgroundColor: AppColors.primary,
                    child: Text(
                      user.fullName.isNotEmpty ? user.fullName[0].toUpperCase() : 'F',
                      style: const TextStyle(fontSize: 36, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(user.fullName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  Text('${user.village}, ${user.district}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                    child: const Text('Verified Farmer Account', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 11)),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Profile Details Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _infoTile(Icons.phone_outlined, 'Mobile Number', user.phone),
                    _infoTile(Icons.email_outlined, 'Email Address', user.email),
                    _infoTile(Icons.eco_outlined, 'Farm Name', user.farmName ?? 'Not specified'),
                    _infoTile(Icons.timeline, 'Farming Experience', user.farmingExperience ?? 'Not specified'),
                    _infoTile(Icons.pin_drop_outlined, 'PIN Code', user.pincode),
                    _infoTile(Icons.grass_rounded, 'Main Crops', user.mainCrops.join(', ')),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            PrimaryButton(
              label: 'Edit Profile Information',
              icon: Icons.edit_outlined,
              onPressed: () => Navigator.pushNamed(context, '/edit_farmer_profile'),
            ),
            const SizedBox(height: 12),

            SecondaryButton(
              label: 'Settings & Preferences',
              icon: Icons.settings_outlined,
              onPressed: () => Navigator.pushNamed(context, '/settings'),
            ),
            const SizedBox(height: 12),

            TextButton.icon(
              onPressed: () async {
                await context.read<AuthState>().logout();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(context, '/role_selection', (route) => false);
                }
              },
              icon: const Icon(Icons.logout, color: AppColors.error),
              label: const Text('Logout', style: TextStyle(color: AppColors.error, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
                Text(val.isEmpty ? 'Not set' : val, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
