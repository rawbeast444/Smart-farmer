import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/formatters.dart';
import '../../../models/crop_model.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/crop_state.dart';
import '../../../state/market_state.dart';

class CropDetailsScreen extends StatelessWidget {
  final CropModel crop;

  const CropDetailsScreen({Key? key, required this.crop}) : super(key: key);

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Crop Record?'),
        content: Text('Are you sure you want to remove ${crop.cropName} (${crop.quantity} ${crop.unit.split(' ').first})?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () async {
              Navigator.pop(ctx);
              await context.read<CropState>().deleteCrop(crop.cropId);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final daysSinceHarvest = DateTime.now().difference(crop.harvestDate).inDays;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('${crop.cropName} Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Delete Crop',
            onPressed: () => _confirmDelete(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Summary Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(crop.cropName, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.primary)),
                        StatusBadge(status: crop.quality),
                      ],
                    ),
                    const Divider(height: 24),
                    _detailRow('Quantity', '${crop.quantity} ${crop.unit}'),
                    _detailRow('Harvest Date', '${AppFormatters.formatDate(crop.harvestDate)} ($daysSinceHarvest days ago)'),
                    _detailRow('Condition', crop.condition),
                    _detailRow('Farm Location', crop.farmerLocation),
                    if (crop.additionalNotes != null && crop.additionalNotes!.isNotEmpty)
                      _detailRow('Notes', crop.additionalNotes!),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            const Text('Recommended Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
            const SizedBox(height: 12),

            // Market Comparison Action
            Card(
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.blue.withOpacity(0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.compare_arrows_rounded, color: Colors.blue),
                ),
                title: const Text('Compare Mandi Market Prices', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Find out which nearby APMC mandi gives the highest net return after transport cost.'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () {
                  context.read<MarketState>().loadMarkets(crop: crop.cropName);
                  Navigator.pushNamed(context, '/market_search');
                },
              ),
            ),
            const SizedBox(height: 12),

            // AI Storage Assistant Action
            Card(
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.auto_awesome, color: AppColors.primary),
                ),
                title: const Text('Run AI Crop Storage Prediction', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Estimate remaining shelf life, cold storage advantages, and spoilage risk.'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => Navigator.pushNamed(context, '/ai_storage', arguments: crop),
              ),
            ),
            const SizedBox(height: 12),

            // Nearby Warehouses Action
            Card(
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.orange.withOpacity(0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.warehouse_rounded, color: Colors.orange),
                ),
                title: const Text('Book Warehouse Storage', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Find accredited cold stores or dry godowns near you to preserve your crop.'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => Navigator.pushNamed(context, '/warehouse_search'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
          Flexible(
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14), textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }
}
