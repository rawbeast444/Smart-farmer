import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../shared/widgets/cards.dart';
import '../../../shared/widgets/ui_states.dart';
import '../../../state/auth_state.dart';
import '../../../state/crop_state.dart';
import '../../../state/market_state.dart';

class MyCropsScreen extends StatelessWidget {
  const MyCropsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthState>().currentUser;
    final cropState = context.watch<CropState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Harvested Crops'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Add Crop',
            onPressed: () => Navigator.pushNamed(context, '/add_crop'),
          ),
        ],
      ),
      body: cropState.isLoading
          ? const LoadingWidget(message: 'Loading your crops...')
          : cropState.crops.isEmpty
              ? EmptyStateWidget(
                  title: 'No Crops Added',
                  description: 'Register your harvest details to unlock mandi price comparisons and AI storage predictions.',
                  icon: Icons.grass_rounded,
                  actionLabel: 'Add Crop',
                  onAction: () => Navigator.pushNamed(context, '/add_crop'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: cropState.crops.length,
                  itemBuilder: (context, index) {
                    final crop = cropState.crops[index];
                    return CropCard(
                      crop: crop,
                      onTap: () => Navigator.pushNamed(context, '/crop_details', arguments: crop),
                      onCompare: () {
                        context.read<MarketState>().loadMarkets(crop: crop.cropName);
                        Navigator.pushNamed(context, '/market_search');
                      },
                      onStoragePrediction: () => Navigator.pushNamed(context, '/ai_storage', arguments: crop),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, '/add_crop'),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Add Crop', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
