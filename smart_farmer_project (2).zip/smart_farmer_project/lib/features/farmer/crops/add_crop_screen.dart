import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/validators.dart';
import '../../../shared/widgets/custom_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/auth_state.dart';
import '../../../state/crop_state.dart';

class AddCropScreen extends StatefulWidget {
  const AddCropScreen({Key? key}) : super(key: key);

  @override
  State<AddCropScreen> createState() => _AddCropScreenState();
}

class _AddCropScreenState extends State<AddCropScreen> {
  final _formKey = GlobalKey<FormState>();

  String _selectedCropName = 'Tomato';
  final _quantityController = TextEditingController();
  String _selectedUnit = AppStrings.unitQuintal;
  DateTime _harvestDate = DateTime.now();
  String _selectedQuality = AppStrings.qualityGood;
  String _selectedCondition = AppStrings.conditionFresh;
  final _locationController = TextEditingController();
  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthState>().currentUser;
    if (user != null) {
      _locationController.text = '${user.village}, ${user.district}';
    }
  }

  void _pickHarvestDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _harvestDate,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _harvestDate = picked);
    }
  }

  void _handleSubmit() async {
    if (_formKey.currentState?.validate() ?? false) {
      final user = context.read<AuthState>().currentUser;
      if (user == null) return;

      final success = await context.read<CropState>().addCrop(
        farmerId: user.uid,
        cropName: _selectedCropName,
        quantity: double.parse(_quantityController.text.trim()),
        unit: _selectedUnit,
        harvestDate: _harvestDate,
        quality: _selectedQuality,
        condition: _selectedCondition,
        farmerLocation: _locationController.text.trim(),
        additionalNotes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      );

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Crop successfully registered!'), backgroundColor: AppColors.success),
        );
        Navigator.pop(context);
      }
    }
  }

  void _handleReset() {
    _formKey.currentState?.reset();
    _quantityController.clear();
    _notesController.clear();
    setState(() {
      _selectedCropName = 'Tomato';
      _selectedUnit = AppStrings.unitQuintal;
      _harvestDate = DateTime.now();
      _selectedQuality = AppStrings.qualityGood;
      _selectedCondition = AppStrings.conditionFresh;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cropState = context.watch<CropState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Add Harvested Crop')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Crop Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
                const SizedBox(height: 14),

                // Crop Name Dropdown
                const Text('Crop Name', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _selectedCropName,
                  items: AppConstants.supportedCrops.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedCropName = val);
                  },
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.grass_rounded, color: AppColors.primary)),
                ),
                const SizedBox(height: 16),

                // Quantity and Unit
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: CustomTextField(
                        controller: _quantityController,
                        label: 'Quantity',
                        hint: 'e.g. 50',
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        prefixIcon: Icons.scale_outlined,
                        validator: (v) => AppValidators.validatePositiveNumber(v, 'Quantity'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Unit', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            value: _selectedUnit,
                            items: const [
                              DropdownMenuItem(value: AppStrings.unitQuintal, child: Text('Quintals (q)')),
                              DropdownMenuItem(value: AppStrings.unitKg, child: Text('Kilograms (kg)')),
                              DropdownMenuItem(value: AppStrings.unitTonne, child: Text('Tonnes (t)')),
                            ],
                            onChanged: (val) {
                              if (val != null) setState(() => _selectedUnit = val);
                            },
                            decoration: const InputDecoration(),
                          ),
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ],
                ),

                // Harvest Date Picker
                const Text('Harvest Date', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                InkWell(
                  onTap: _pickHarvestDate,
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.calendar_today_outlined, color: AppColors.primary, size: 20),
                            const SizedBox(width: 12),
                            Text(AppFormatters.formatDate(_harvestDate), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                          ],
                        ),
                        const Icon(Icons.edit, size: 18, color: AppColors.textSecondary),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Crop Quality
                const Text('Crop Quality Grade', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _selectedQuality,
                  items: const [
                    DropdownMenuItem(value: AppStrings.qualityPremium, child: Text('Premium (A Grade, No defects)')),
                    DropdownMenuItem(value: AppStrings.qualityGood, child: Text('Good (Standard Mandi Quality)')),
                    DropdownMenuItem(value: AppStrings.qualityAverage, child: Text('Average (Mixed size/color)')),
                    DropdownMenuItem(value: AppStrings.qualityPoor, child: Text('Poor (Damaged/Overripe)')),
                  ],
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedQuality = val);
                  },
                ),
                const SizedBox(height: 16),

                // Crop Condition
                const Text('Crop Physical Condition', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: _selectedCondition,
                  items: const [
                    DropdownMenuItem(value: AppStrings.conditionFresh, child: Text('Freshly Harvested')),
                    DropdownMenuItem(value: AppStrings.conditionSlightlyDamaged, child: Text('Slightly Damaged (Skin bruises)')),
                    DropdownMenuItem(value: AppStrings.conditionDamaged, child: Text('Damaged (Requires fast liquidation)')),
                  ],
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedCondition = val);
                  },
                ),
                const SizedBox(height: 16),

                CustomTextField(
                  controller: _locationController,
                  label: 'Farm Location / Mandi Distance Hub',
                  hint: 'Village, District',
                  prefixIcon: Icons.location_on_outlined,
                  validator: (v) => AppValidators.validateRequired(v, 'Location'),
                ),

                CustomTextField(
                  controller: _notesController,
                  label: 'Additional Notes (Optional)',
                  hint: 'Seed variety, moisture %, packaging type etc.',
                  maxLines: 2,
                  prefixIcon: Icons.notes_outlined,
                ),

                const SizedBox(height: 24),
                PrimaryButton(
                  label: 'Submit Crop',
                  isLoading: cropState.isLoading,
                  onPressed: _handleSubmit,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _handleReset,
                        child: const Text('Reset Form'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
