import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/calculations.dart';
import '../../../core/utils/formatters.dart';
import '../../../models/market_price_model.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/primary_button.dart';

class MarketDetailsScreen extends StatefulWidget {
  final MarketPriceModel market;

  const MarketDetailsScreen({Key? key, required this.market}) : super(key: key);

  @override
  State<MarketDetailsScreen> createState() => _MarketDetailsScreenState();
}

class _MarketDetailsScreenState extends State<MarketDetailsScreen> {
  double _sampleQuantity = 50.0; // default 50 quintals

  @override
  Widget build(BuildContext context) {
    final m = widget.market;
    final transportCost = AgriculturalCalculations.calculateTransportCost(
      quantityInQuintals: _sampleQuantity,
      distanceKm: m.distanceKm,
    );
    final gross = AgriculturalCalculations.calculateGrossRevenue(
      quantityInQuintals: _sampleQuantity,
      pricePerQuintal: m.averagePrice,
    );
    final net = AgriculturalCalculations.calculateNetValue(
      grossRevenue: gross,
      transportCost: transportCost,
    );

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(m.marketName),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const DemoBannerWidget(text: AppStrings.demoBadge),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Mandi Header Card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  m.marketName,
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primary),
                                ),
                              ),
                              StatusBadge(status: '${m.demand} Demand'),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
                              const SizedBox(width: 4),
                              Text('${m.city}, District ${m.district}, ${m.state}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.directions_car_outlined, size: 16, color: AppColors.textSecondary),
                              const SizedBox(width: 4),
                              Text('${m.distanceKm} km from your farm location', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                            ],
                          ),
                          const Divider(height: 24),

                          // Price details
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('${m.cropName} Average Price', style: const TextStyle(color: AppColors.textLight, fontSize: 12)),
                                  const SizedBox(height: 4),
                                  Text(
                                    AppFormatters.formatCurrency(m.averagePrice),
                                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: AppColors.primary),
                                  ),
                                  Text(m.priceUnit, style: const TextStyle(color: AppColors.textLight, fontSize: 11)),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text('Minimum: ₹${m.minPrice.toInt()}/q', style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                                  Text('Maximum: ₹${m.maxPrice.toInt()}/q', style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                                  const SizedBox(height: 4),
                                  Text('Source: ${m.dataSource}', style: const TextStyle(color: AppColors.textLight, fontSize: 10)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Interactive Net Return Calculator
                  const Text('Estimated Net Value Calculator', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  const SizedBox(height: 6),
                  const Text('Adjust harvest quantity to calculate actual profit after transportation expenses.', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  const SizedBox(height: 12),

                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Harvest Quantity (Quintals):', style: TextStyle(fontWeight: FontWeight.w600)),
                              Text('${_sampleQuantity.toInt()} q', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary)),
                            ],
                          ),
                          Slider(
                            value: _sampleQuantity,
                            min: 5,
                            max: 200,
                            divisions: 39,
                            activeColor: AppColors.primary,
                            onChanged: (val) => setState(() => _sampleQuantity = val),
                          ),
                          const Divider(height: 20),
                          _mathRow('Gross Mandi Revenue', AppFormatters.formatCurrency(gross), isPositive: true),
                          _mathRow('Estimated Transport Cost (${m.distanceKm} km)', '- ${AppFormatters.formatCurrency(transportCost)}', isNegative: true),
                          const Divider(height: 16),
                          _mathRow('Estimated Net Return to Farmer', AppFormatters.formatCurrency(net), isBold: true, isHighlight: true),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Mandi Infrastructure & Hours
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('APMC Mandi Information', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          SizedBox(height: 10),
                          Text('• Auction Hours: 08:00 AM – 02:00 PM (Monday to Saturday)'),
                          SizedBox(height: 6),
                          Text('• Electronic Weighing Scales: Active & Certified'),
                          SizedBox(height: 6),
                          Text('• Direct e-NAM settlement / Cash payment available on same day.'),
                          SizedBox(height: 6),
                          Text('• Unloading and dunnage sheds available for perishable goods.'),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  PrimaryButton(
                    label: 'Get Directions on Map',
                    icon: Icons.navigation_outlined,
                    onPressed: () {
                      Navigator.pushNamed(context, '/market_map', arguments: m);
                    },
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _mathRow(String label, String value, {bool isPositive = false, bool isNegative = false, bool isBold = false, bool isHighlight = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: isBold ? 15 : 13,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: isHighlight ? AppColors.primary : AppColors.textPrimary,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: isBold ? 16 : 13,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
              color: isNegative
                  ? AppColors.error
                  : isHighlight
                      ? AppColors.primary
                      : AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
