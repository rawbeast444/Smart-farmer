import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/services/map_service.dart';
import '../../../models/market_price_model.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../state/market_state.dart';
import '../../../state/warehouse_state.dart';

class MarketMapScreen extends StatefulWidget {
  final MarketPriceModel? focusedMarket;

  const MarketMapScreen({Key? key, this.focusedMarket}) : super(key: key);

  @override
  State<MarketMapScreen> createState() => _MarketMapScreenState();
}

class _MarketMapScreenState extends State<MarketMapScreen> {
  String _selectedDistrict = 'Sangli';
  MarketPriceModel? _selectedMarket;

  @override
  void initState() {
    super.initState();
    _selectedMarket = widget.focusedMarket;
  }

  @override
  Widget build(BuildContext context) {
    final marketState = context.watch<MarketState>();
    final warehouseState = context.watch<WarehouseState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Agricultural Discovery Map'),
      ),
      body: Column(
        children: [
          const DemoBannerWidget(text: 'MAP DEMO – Real GPS coords & interactive pins preview'),

          // Interactive Map Simulation Surface
          Container(
            height: 280,
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xFFE3EBDC),
            ),
            child: Stack(
              children: [
                // Stylized map grid background
                CustomPaint(
                  size: Size.infinite,
                  painter: _MapGridPainter(),
                ),

                // Center Farmer Pin
                Positioned(
                  top: 130,
                  left: 170,
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                        ),
                        child: const Icon(Icons.person_pin_circle, color: Colors.white, size: 24),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(4)),
                        child: const Text('Your Farm', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),

                // Market Pin 1 (Sangli)
                Positioned(
                  top: 60,
                  left: 80,
                  child: _mapPin(
                    title: 'Sangli APMC',
                    color: Colors.blue.shade700,
                    icon: Icons.storefront,
                    distance: '18 km',
                  ),
                ),

                // Market Pin 2 (Kolhapur)
                Positioned(
                  top: 180,
                  left: 60,
                  child: _mapPin(
                    title: 'Kolhapur APMC',
                    color: Colors.blue.shade700,
                    icon: Icons.storefront,
                    distance: '48 km',
                  ),
                ),

                // Warehouse Pin 1 (Miraj)
                Positioned(
                  top: 90,
                  right: 70,
                  child: _mapPin(
                    title: 'Miraj Cold Store',
                    color: Colors.orange.shade800,
                    icon: Icons.warehouse,
                    distance: '14 km',
                  ),
                ),

                // Warehouse Pin 2 (Krishna Valley)
                Positioned(
                  top: 200,
                  right: 90,
                  child: _mapPin(
                    title: 'Krishna Valley Godown',
                    color: Colors.orange.shade800,
                    icon: Icons.warehouse,
                    distance: '6 km',
                  ),
                ),

                // Map Legend
                Positioned(
                  bottom: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _legendDot(Colors.blue.shade700, 'APMC Mandi'),
                        const SizedBox(width: 10),
                        _legendDot(Colors.orange.shade800, 'Warehouse'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // District selector fallback
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                const Text('Select District:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedDistrict,
                    items: AppConstants.maharashtraDistricts.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        setState(() => _selectedDistrict = val);
                        context.read<MarketState>().loadMarkets(district: val);
                      }
                    },
                    decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
                  ),
                ),
              ],
            ),
          ),

          // Discovered Mandis & Warehouses List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                const Text('Nearby Mandis along Highway Routes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                ...marketState.markets.take(3).map((m) {
                  final travelTime = MapService.estimateTravelTimeMinutes(m.distanceKm);
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFE3F2FD),
                        child: Icon(Icons.storefront, color: Color(0xFF1976D2)),
                      ),
                      title: Text(m.marketName, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${m.distanceKm} km • ~${travelTime ~/ 60}h ${travelTime % 60}m transit via NH-166'),
                      trailing: const Icon(Icons.directions, color: AppColors.primary),
                      onTap: () => Navigator.pushNamed(context, '/market_details', arguments: m),
                    ),
                  );
                }),
                const SizedBox(height: 14),
                const Text('Nearby Certified Storages', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                ...warehouseState.warehouses.take(2).map((w) {
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFFFF3E0),
                        child: Icon(Icons.warehouse, color: Color(0xFFE65100)),
                      ),
                      title: Text(w.warehouseName, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${w.storageType} • ${w.distanceKm} km away • ₹${w.storageCharges.toInt()}/q'),
                      trailing: const Icon(Icons.directions, color: AppColors.primary),
                      onTap: () => Navigator.pushNamed(context, '/warehouse_details', arguments: w),
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _mapPin({required String title, required Color color, required IconData icon, required String distance}) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
          ),
          child: Icon(icon, color: Colors.white, size: 16),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4), border: Border.all(color: color, width: 0.8)),
          child: Text('$title ($distance)', style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }

  Widget _legendDot(Color color, String label) {
    return Row(
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w500)),
      ],
    );
  }
}

class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.green.withOpacity(0.08)
      ..strokeWidth = 1.0;

    for (double i = 0; i < size.width; i += 30) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }
    for (double j = 0; j < size.height; j += 30) {
      canvas.drawLine(Offset(0, j), Offset(size.width, j), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
