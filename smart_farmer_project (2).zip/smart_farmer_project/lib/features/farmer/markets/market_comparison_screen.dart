import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../models/market_price_model.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../../state/crop_state.dart';
import '../../../state/market_state.dart';

class MarketComparisonScreen extends StatefulWidget {
  final List<MarketPriceModel> markets;

  const MarketComparisonScreen({Key? key, required this.markets}) : super(key: key);

  @override
  State<MarketComparisonScreen> createState() => _MarketComparisonScreenState();
}

class _MarketComparisonScreenState extends State<MarketComparisonScreen> {
  double _cropQuantity = 50.0;
  String _quantityUnit = AppStrings.unitQuintal;

  @override
  void initState() {
    super.initState();
    final crops = context.read<CropState>().crops;
    if (crops.isNotEmpty) {
      _cropQuantity = crops.first.quantity;
      _quantityUnit = crops.first.unit;
    }
  }

  @override
  Widget build(BuildContext context) {
    final marketState = context.watch<MarketState>();
    final recommendation = marketState.getRecommendation(
      quantity: _cropQuantity,
      unit: _quantityUnit,
      targetMarkets: widget.markets,
    );

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Market Comparison'),
        actions: [
          IconButton(
            icon: const Icon(Icons.auto_awesome),
            tooltip: 'View Recommendation',
            onPressed: () {
              Navigator.pushNamed(context, '/market_recommendation', arguments: recommendation);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const DemoBannerWidget(text: AppStrings.demoBadge),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Quantity adjustment card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Crop Quantity for Comparison', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  'Calculating for ${_cropQuantity.toStringAsFixed(0)} $_quantityUnit',
                                  style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
                                ),
                              ),
                              DropdownButton<String>(
                                value: _quantityUnit,
                                items: const [
                                  DropdownMenuItem(value: AppStrings.unitQuintal, child: Text('Quintals')),
                                  DropdownMenuItem(value: AppStrings.unitKg, child: Text('Kg')),
                                  DropdownMenuItem(value: AppStrings.unitTonne, child: Text('Tonnes')),
                                ],
                                onChanged: (v) {
                                  if (v != null) setState(() => _quantityUnit = v);
                                },
                              ),
                            ],
                          ),
                          Slider(
                            value: _cropQuantity.clamp(1, 200),
                            min: 1,
                            max: 200,
                            divisions: 199,
                            activeColor: AppColors.primary,
                            onChanged: (val) => setState(() => _cropQuantity = val),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Comparison Table Card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Side-by-Side Market Matrix',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primary),
                          ),
                          const SizedBox(height: 12),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: DataTable(
                              headingRowColor: MaterialStateProperty.all(AppColors.surfaceVariant),
                              columnSpacing: 20,
                              columns: [
                                const DataColumn(label: Text('Parameter', style: TextStyle(fontWeight: FontWeight.bold))),
                                ...recommendation.rankedMarkets.map(
                                  (item) => DataColumn(
                                    label: Text(
                                      item.market.marketName.split(' ').first,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: item.market.marketId == recommendation.bestMarket.marketId
                                            ? AppColors.primary
                                            : AppColors.textPrimary,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                              rows: [
                                DataRow(cells: [
                                  const DataCell(Text('Average Price')),
                                  ...recommendation.rankedMarkets.map((i) => DataCell(Text('₹${i.market.averagePrice.toInt()}/q'))),
                                ]),
                                DataRow(cells: [
                                  const DataCell(Text('Min – Max Price')),
                                  ...recommendation.rankedMarkets.map((i) => DataCell(Text('₹${i.market.minPrice.toInt()} – ₹${i.market.maxPrice.toInt()}'))),
                                ]),
                                DataRow(cells: [
                                  const DataCell(Text('Market Demand')),
                                  ...recommendation.rankedMarkets.map((i) => DataCell(Text(i.market.demand))),
                                ]),
                                DataRow(cells: [
                                  const DataCell(Text('Distance')),
                                  ...recommendation.rankedMarkets.map((i) => DataCell(Text('${i.distanceKm} km'))),
                                ]),
                                DataRow(cells: [
                                  const DataCell(Text('Transport Cost')),
                                  ...recommendation.rankedMarkets.map((i) => DataCell(Text('₹${i.transportCost.toInt()}', style: const TextStyle(color: AppColors.error)))),
                                ]),
                                DataRow(
                                  color: MaterialStateProperty.all(AppColors.primary.withOpacity(0.06)),
                                  cells: [
                                    const DataCell(Text('Estimated Net Value', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary))),
                                    ...recommendation.rankedMarkets.map(
                                      (i) => DataCell(
                                        Text(
                                          '₹${i.netValue.toInt()}',
                                          style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary, fontSize: 15),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Recommendation banner
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFC8E6C9)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: const [
                            Icon(Icons.stars_rounded, color: AppColors.primary, size: 24),
                            SizedBox(width: 8),
                            Text('Best Recommendation', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primary)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          recommendation.reasoning,
                          style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textPrimary),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  PrimaryButton(
                    label: 'View Detailed Recommendation Analysis',
                    icon: Icons.analytics_outlined,
                    onPressed: () {
                      Navigator.pushNamed(context, '/market_recommendation', arguments: recommendation);
                    },
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
