import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/repositories/market_repository.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/primary_button.dart';

class MarketRecommendationScreen extends StatelessWidget {
  final MarketRecommendationResult recommendation;

  const MarketRecommendationScreen({Key? key, required this.recommendation}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final best = recommendation.bestMarket;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Market Recommendation Engine'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const DemoBannerWidget(text: AppStrings.demoBadge),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Choice Trophy Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1B5E20), Color(0xFF2E7D32)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(color: AppColors.primary.withOpacity(0.2), blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.verified, color: AppColors.accent, size: 16),
                                  SizedBox(width: 4),
                                  Text('#1 Best Return', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                                ],
                              ),
                            ),
                            Text('${best.distanceKm} km away', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Text(
                          best.marketName,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        Text('${best.city}, ${best.district}', style: const TextStyle(color: AppColors.accent, fontSize: 14)),
                        const SizedBox(height: 18),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Estimated Net Value', style: TextStyle(color: Colors.white70, fontSize: 12)),
                                Text(
                                  AppFormatters.formatCurrency(recommendation.estimatedNetValue),
                                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const Text('Transport Cost', style: TextStyle(color: Colors.white70, fontSize: 12)),
                                Text(
                                  AppFormatters.formatCurrency(recommendation.estimatedTransportCost),
                                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.accent),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Recommendation Reasoning
                  const Text('Why This Market Is Recommended', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  const SizedBox(height: 10),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.lightbulb_outline, color: Colors.orange, size: 24),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  recommendation.reasoning,
                                  style: const TextStyle(fontSize: 14, height: 1.4, color: AppColors.textPrimary),
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          const Text('Key Deciding Factors Considered:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          const SizedBox(height: 8),
                          _factorBullet('Expected Selling Price', '₹${best.averagePrice.toInt()}/quintal (Market Demand: ${best.demand})'),
                          _factorBullet('Logistics Optimization', 'Balanced travel distance (${best.distanceKm} km) vs freight costs'),
                          _factorBullet('Data Reliability', 'Sourced from ${best.dataSource} with recent trading volumes'),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Ranking of All Analyzed Mandis
                  const Text('Market Return Rankings', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  const SizedBox(height: 10),

                  ...recommendation.rankedMarkets.asMap().entries.map((entry) {
                    final rank = entry.key + 1;
                    final item = entry.value;
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: rank == 1 ? AppColors.primary : AppColors.surfaceVariant,
                          foregroundColor: rank == 1 ? Colors.white : AppColors.textPrimary,
                          child: Text('#$rank', style: const TextStyle(fontWeight: FontWeight.bold)),
                        ),
                        title: Text(item.market.marketName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        subtitle: Text('${item.distanceKm} km • Mandi Price: ₹${item.market.averagePrice.toInt()}/q'),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              AppFormatters.formatCurrency(item.netValue),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                color: rank == 1 ? AppColors.primary : AppColors.textPrimary,
                              ),
                            ),
                            Text('Net Return', style: TextStyle(fontSize: 10, color: AppColors.textLight)),
                          ],
                        ),
                      ),
                    );
                  }).toList(),

                  const SizedBox(height: 20),

                  // Disclaimer
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.amber.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.amber.shade300),
                    ),
                    child: const Text(
                      'DISCLAIMER: Recommendations and net values are mathematical estimations based on indicative mandi rates and standard rural freight factors. Actual auction bids and fuel/toll charges may vary on the day of sale.',
                      style: TextStyle(fontSize: 11, color: Colors.black87),
                    ),
                  ),

                  const SizedBox(height: 24),
                  PrimaryButton(
                    label: 'Proceed to ${best.marketName}',
                    icon: Icons.check_circle_outline,
                    onPressed: () {
                      Navigator.pushNamed(context, '/market_details', arguments: best);
                    },
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _factorBullet(String title, String desc) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.check, size: 16, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                children: [
                  TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.bold)),
                  TextSpan(text: desc),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
