import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../shared/widgets/ui_states.dart';
import '../../state/notification_state.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<NotificationState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          if (state.notifications.isNotEmpty)
            TextButton(
              onPressed: () => state.markAllAsRead(),
              child: const Text('Mark All Read', style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
        ],
      ),
      body: state.notifications.isEmpty
          ? const EmptyStateWidget(
              title: 'No Notifications',
              description: 'You are all caught up on market alerts and warehouse enquiries.',
              icon: Icons.notifications_none,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: state.notifications.length,
              itemBuilder: (context, index) {
                final n = state.notifications[index];
                return Card(
                  color: n.isRead ? AppColors.surface : const Color(0xFFF1F8E9),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _iconColor(n.type).withOpacity(0.15),
                      child: Icon(_getIcon(n.type), color: _iconColor(n.type)),
                    ),
                    title: Text(n.title, style: TextStyle(fontWeight: n.isRead ? FontWeight.normal : FontWeight.bold, fontSize: 14)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text(n.message, style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(AppFormatters.formatDate(n.timestamp), style: const TextStyle(fontSize: 10, color: AppColors.textLight)),
                      ],
                    ),
                    onTap: () => state.markAsRead(n.id),
                  ),
                );
              },
            ),
    );
  }

  IconData _getIcon(String type) {
    switch (type) {
      case 'weather':
        return Icons.cloud_outlined;
      case 'market':
        return Icons.trending_up;
      case 'enquiry':
        return Icons.warehouse_outlined;
      default:
        return Icons.info_outline;
    }
  }

  Color _iconColor(String type) {
    switch (type) {
      case 'weather':
        return Colors.blue;
      case 'market':
        return AppColors.primary;
      case 'enquiry':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}
