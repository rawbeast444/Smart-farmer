import 'package:flutter/foundation.dart';
import '../models/notification_model.dart';
import '../data/repositories/notification_repository.dart';

class NotificationState extends ChangeNotifier {
  final NotificationRepository _repository;
  List<AppNotification> _notifications = [];

  NotificationState(this._repository);

  List<AppNotification> get notifications => _notifications;
  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  Future<void> loadNotifications(String userId, String role) async {
    _notifications = await _repository.getNotifications(userId, role);
    notifyListeners();
  }

  void markAsRead(String id) {
    _repository.markAsRead(id);
    final idx = _notifications.indexWhere((n) => n.id == id);
    if (idx != -1) {
      _notifications[idx] = _notifications[idx].copyWith(isRead: true);
      notifyListeners();
    }
  }

  void markAllAsRead() {
    _repository.markAllAsRead();
    for (int i = 0; i < _notifications.length; i++) {
      _notifications[i] = _notifications[i].copyWith(isRead: true);
    }
    notifyListeners();
  }
}
