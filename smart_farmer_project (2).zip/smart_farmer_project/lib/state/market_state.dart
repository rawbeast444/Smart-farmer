import 'package:flutter/foundation.dart';
import '../models/market_price_model.dart';
import '../data/repositories/market_repository.dart';

class MarketState extends ChangeNotifier {
  final MarketRepository _repository;
  List<MarketPriceModel> _markets = [];
  bool _isLoading = false;
  String _selectedCrop = 'All';
  String _selectedDistrict = 'All';
  String _selectedSortBy = 'Nearest Market';
  String _searchQuery = '';
  
  // Multi-market comparison selection
  final List<MarketPriceModel> _selectedMarketsForComparison = [];

  MarketState(this._repository);

  List<MarketPriceModel> get markets => _markets;
  bool get isLoading => _isLoading;
  String get selectedCrop => _selectedCrop;
  String get selectedDistrict => _selectedDistrict;
  String get selectedSortBy => _selectedSortBy;
  List<MarketPriceModel> get selectedMarketsForComparison => _selectedMarketsForComparison;

  void toggleComparisonSelection(MarketPriceModel market) {
    final exists = _selectedMarketsForComparison.any((m) => m.marketId == market.marketId);
    if (exists) {
      _selectedMarketsForComparison.removeWhere((m) => m.marketId == market.marketId);
    } else {
      if (_selectedMarketsForComparison.length < 4) {
        _selectedMarketsForComparison.add(market);
      }
    }
    notifyListeners();
  }

  void clearComparisonSelection() {
    _selectedMarketsForComparison.clear();
    notifyListeners();
  }

  Future<void> loadMarkets({
    String? crop,
    String? district,
    String? sortBy,
    String? query,
  }) async {
    _isLoading = true;
    notifyListeners();

    if (crop != null) _selectedCrop = crop;
    if (district != null) _selectedDistrict = district;
    if (sortBy != null) _selectedSortBy = sortBy;
    if (query != null) _searchQuery = query;

    try {
      _markets = await _repository.getMarkets(
        cropName: _selectedCrop == 'All' ? null : _selectedCrop,
        district: _selectedDistrict == 'All' ? null : _selectedDistrict,
        sortBy: _selectedSortBy,
        searchQuery: _searchQuery,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      notifyListeners();
    }
  }

  MarketRecommendationResult getRecommendation({
    required double quantity,
    required String unit,
    List<MarketPriceModel>? targetMarkets,
  }) {
    final list = targetMarkets ?? (_selectedMarketsForComparison.isNotEmpty ? _selectedMarketsForComparison : _markets);
    return _repository.recommendBestMarket(
      markets: list,
      cropQuantity: quantity,
      quantityUnit: unit,
    );
  }
}
