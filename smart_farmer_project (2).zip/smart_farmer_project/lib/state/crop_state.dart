import 'package:flutter/foundation.dart';
import '../models/crop_model.dart';
import '../data/repositories/crop_repository.dart';

class CropState extends ChangeNotifier {
  final CropRepository _repository;
  List<CropModel> _crops = [];
  bool _isLoading = false;
  String? _errorMessage;
  CropModel? _selectedCropForAction;

  CropState(this._repository);

  List<CropModel> get crops => _crops;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  CropModel? get selectedCropForAction => _selectedCropForAction;

  void selectCropForAction(CropModel? crop) {
    _selectedCropForAction = crop;
    notifyListeners();
  }

  Future<void> loadCrops(String farmerId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _crops = await _repository.getFarmerCrops(farmerId);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<bool> addCrop({
    required String farmerId,
    required String cropName,
    required double quantity,
    required String unit,
    required DateTime harvestDate,
    required String quality,
    required String condition,
    required String farmerLocation,
    String? additionalNotes,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final newCrop = await _repository.addCrop(
        farmerId: farmerId,
        cropName: cropName,
        quantity: quantity,
        unit: unit,
        harvestDate: harvestDate,
        quality: quality,
        condition: condition,
        farmerLocation: farmerLocation,
        additionalNotes: additionalNotes,
      );
      _crops.insert(0, newCrop);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateCrop(CropModel crop) async {
    try {
      final updated = await _repository.updateCrop(crop);
      final idx = _crops.indexWhere((c) => c.cropId == updated.cropId);
      if (idx != -1) {
        _crops[idx] = updated;
        notifyListeners();
      }
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteCrop(String cropId) async {
    try {
      final success = await _repository.deleteCrop(cropId);
      if (success) {
        _crops.removeWhere((c) => c.cropId == cropId);
        notifyListeners();
      }
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }
}
