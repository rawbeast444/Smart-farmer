import 'package:flutter/foundation.dart';
import '../models/warehouse_model.dart';
import '../models/storage_request_model.dart';
import '../data/repositories/warehouse_repository.dart';
import '../data/repositories/storage_request_repository.dart';

class WarehouseState extends ChangeNotifier {
  final WarehouseRepository _warehouseRepo;
  final StorageRequestRepository _requestRepo;

  List<WarehouseModel> _warehouses = [];
  WarehouseModel? _currentOwnerWarehouse;
  List<StorageRequestModel> _farmerEnquiries = [];
  List<StorageRequestModel> _ownerEnquiries = [];
  bool _isLoading = false;
  String? _errorMessage;

  WarehouseState(this._warehouseRepo, this._requestRepo);

  List<WarehouseModel> get warehouses => _warehouses;
  WarehouseModel? get currentOwnerWarehouse => _currentOwnerWarehouse;
  List<StorageRequestModel> get farmerEnquiries => _farmerEnquiries;
  List<StorageRequestModel> get ownerEnquiries => _ownerEnquiries;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> searchWarehouses({
    String? district,
    String? storageType,
    double? minCapacity,
    double? maxCharges,
    String? query,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      _warehouses = await _warehouseRepo.searchWarehouses(
        district: district,
        storageType: storageType,
        minCapacity: minCapacity,
        maxCharges: maxCharges,
        searchQuery: query,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> loadOwnerWarehouse(String ownerId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _currentOwnerWarehouse = await _warehouseRepo.getOwnerWarehouse(ownerId);
      _ownerEnquiries = await _requestRepo.getWarehouseRequests(ownerId);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> loadFarmerEnquiries(String farmerId) async {
    try {
      _farmerEnquiries = await _requestRepo.getFarmerRequests(farmerId);
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<bool> submitEnquiry({
    required String farmerId,
    required String farmerName,
    required String farmerContact,
    required String warehouseId,
    required String warehouseOwnerId,
    required String warehouseName,
    required String cropName,
    required double quantity,
    required String unit,
    required int durationMonths,
    required String preferredStorageType,
    String? additionalNotes,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final req = await _requestRepo.submitEnquiry(
        farmerId: farmerId,
        farmerName: farmerName,
        farmerContact: farmerContact,
        warehouseId: warehouseId,
        warehouseOwnerId: warehouseOwnerId,
        warehouseName: warehouseName,
        cropName: cropName,
        quantity: quantity,
        unit: unit,
        durationMonths: durationMonths,
        preferredStorageType: preferredStorageType,
        additionalNotes: additionalNotes,
      );
      _farmerEnquiries.insert(0, req);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateEnquiryStatus({
    required String requestId,
    required String status,
    required String ownerId,
  }) async {
    try {
      final updated = await _requestRepo.updateStatus(requestId: requestId, newStatus: status);
      final idx = _ownerEnquiries.indexWhere((r) => r.requestId == requestId);
      if (idx != -1) {
        _ownerEnquiries[idx] = updated;
      }
      // Reload warehouse to reflect altered capacity
      _currentOwnerWarehouse = await _warehouseRepo.getOwnerWarehouse(ownerId);
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateWarehouseDetails(WarehouseModel updated) async {
    try {
      _currentOwnerWarehouse = await _warehouseRepo.updateWarehouse(updated);
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      return false;
    }
  }
}
