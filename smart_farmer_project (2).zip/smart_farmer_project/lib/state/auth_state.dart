import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../data/repositories/auth_repository.dart';

class AuthState extends ChangeNotifier {
  final AuthRepository _repository;
  bool _isLoading = false;
  String? _errorMessage;

  AuthState(this._repository);

  AppUser? get currentUser => _repository.currentUser;
  bool get isAuthenticated => _repository.isAuthenticated;
  bool get isFarmer => _repository.currentUser?.isFarmer ?? true;
  bool get isWarehouseOwner => _repository.currentUser?.isWarehouseOwner ?? false;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<bool> login({
    required String emailOrPhone,
    required String password,
    required String role,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _repository.login(
        emailOrPhone: emailOrPhone,
        password: password,
        role: role,
      );
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      return false;
    }
  }

  Future<bool> register({
    required String fullName,
    required String email,
    required String phone,
    required String password,
    required String role,
    required String state,
    required String district,
    required String village,
    required String pincode,
    String? farmName,
    String? farmingExperience,
    List<String> mainCrops = const [],
    String? businessName,
    String? warehouseName,
    String? warehouseAddress,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _repository.register(
        fullName: fullName,
        email: email,
        phone: phone,
        password: password,
        role: role,
        state: state,
        district: district,
        village: village,
        pincode: pincode,
        farmName: farmName,
        farmingExperience: farmingExperience,
        mainCrops: mainCrops,
        businessName: businessName,
        warehouseName: warehouseName,
        warehouseAddress: warehouseAddress,
      );
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      return false;
    }
  }

  Future<void> switchDemoAccount(String role) async {
    await _repository.switchDemoAccount(role);
    notifyListeners();
  }

  Future<void> updateProfile(AppUser updated) async {
    await _repository.updateProfile(updated);
    notifyListeners();
  }

  Future<void> logout() async {
    await _repository.logout();
    notifyListeners();
  }
}
