import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/constants/app_strings.dart';
import 'core/theme/app_theme.dart';
import 'core/routing/app_router.dart';
import 'data/repositories/auth_repository.dart';
import 'data/repositories/crop_repository.dart';
import 'data/repositories/market_repository.dart';
import 'data/repositories/warehouse_repository.dart';
import 'data/repositories/storage_request_repository.dart';
import 'data/repositories/notification_repository.dart';
import 'state/auth_state.dart';
import 'state/crop_state.dart';
import 'state/market_state.dart';
import 'state/warehouse_state.dart';
import 'state/notification_state.dart';

class SmartFarmerApp extends StatelessWidget {
  const SmartFarmerApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Instantiate core repositories
    final authRepo = AuthRepository();
    final cropRepo = CropRepository();
    final marketRepo = MarketRepository();
    final warehouseRepo = WarehouseRepository();
    final storageReqRepo = StorageRequestRepository(warehouseRepo);
    final notifRepo = NotificationRepository();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthState(authRepo)),
        ChangeNotifierProvider(create: (_) => CropState(cropRepo)),
        ChangeNotifierProvider(create: (_) => MarketState(marketRepo)),
        ChangeNotifierProvider(create: (_) => WarehouseState(warehouseRepo, storageReqRepo)),
        ChangeNotifierProvider(create: (_) => NotificationState(notifRepo)),
      ],
      child: MaterialApp(
        title: AppStrings.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        initialRoute: '/',
        onGenerateRoute: AppRouter.generateRoute,
      ),
    );
  }
}
