import 'package:uuid/uuid.dart';
import '../../models/warehouse_model.dart';
import '../datasources/demo_data.dart';

class WarehouseRepository {
  final List<WarehouseModel> _warehouses = [];
  final _uuid = const Uuid();

  WarehouseRepository() {
    _warehouses.addAll(DemoData.getDemoWarehouses());
  }

  Future<List<WarehouseModel>> searchWarehouses({
    String? district,
    String? storageType,
    double? minCapacity,
    double? maxCharges,
    String? searchQuery,
  }) async {
    await Future.delayed(const Duration(milliseconds: 250));

    var list = _warehouses;
    if (district != null && district.isNotEmpty && district != 'All') {
      list = list.where((w) => w.district.toLowerCase() == district.toLowerCase()).toList();
    }
    if (storageType != null && storageType.isNotEmpty && storageType != 'All') {
      list = list.where((w) => w.storageType.toLowerCase() == storageType.toLowerCase()).toList();
    }
    if (minCapacity != null) {
      list = list.where((w) => w.availableCapacity >= minCapacity).toList();
    }
    if (maxCharges != null) {
      list = list.where((w) => w.storageCharges <= maxCharges).toList();
    }
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final q = searchQuery.toLowerCase().trim();
      list = list.where((w) =>
          w.warehouseName.toLowerCase().contains(q) ||
          w.district.toLowerCase().contains(q) ||
          w.address.toLowerCase().contains(q) ||
          w.ownerName.toLowerCase().contains(q)).toList();
    }

    // Sort by nearest distance by default
    list.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
    return list;
  }

  Future<WarehouseModel?> getWarehouseById(String warehouseId) async {
    final list = _warehouses.where((w) => w.warehouseId == warehouseId);
    return list.isNotEmpty ? list.first : null;
  }

  Future<WarehouseModel?> getOwnerWarehouse(String ownerId) async {
    await Future.delayed(const Duration(milliseconds: 150));
    final list = _warehouses.where((w) => w.ownerId == ownerId || w.ownerId == 'demo_owner_1');
    return list.isNotEmpty ? list.first : null;
  }

  Future<WarehouseModel> registerWarehouse({
    required String ownerId,
    required String ownerName,
    required String warehouseName,
    required String address,
    required String district,
    required String state,
    required double totalCapacity,
    required double availableCapacity,
    required String storageType,
    required double storageCharges,
    required String contactNumber,
    String? temperatureRange,
  }) async {
    await Future.delayed(const Duration(milliseconds: 400));

    // Capacity validation check
    if (availableCapacity > totalCapacity) {
      throw ArgumentError('Available capacity cannot exceed total capacity');
    }

    final newWarehouse = WarehouseModel(
      warehouseId: 'wh_${_uuid.v4().substring(0, 8)}',
      ownerId: ownerId,
      warehouseName: warehouseName,
      ownerName: ownerName,
      address: address,
      district: district,
      state: state,
      totalCapacity: totalCapacity,
      availableCapacity: availableCapacity,
      storageType: storageType,
      storageCharges: storageCharges,
      contactNumber: contactNumber,
      temperatureRange: temperatureRange,
      distanceKm: 12.0,
    );

    _warehouses.insert(0, newWarehouse);
    return newWarehouse;
  }

  Future<WarehouseModel> updateWarehouse(WarehouseModel updated) async {
    await Future.delayed(const Duration(milliseconds: 300));

    // Capacity validation:
    if (updated.availableCapacity > updated.totalCapacity) {
      throw ArgumentError('Available capacity cannot exceed total capacity.');
    }
    if (updated.availableCapacity < 0 || updated.totalCapacity < 0) {
      throw ArgumentError('Capacity cannot be negative.');
    }

    final index = _warehouses.indexWhere((w) => w.warehouseId == updated.warehouseId);
    if (index != -1) {
      _warehouses[index] = updated;
      return updated;
    }
    throw Exception('Warehouse not found');
  }

  /// Reduces available capacity upon accepting storage request
  Future<void> adjustCapacityForAcceptedRequest(String warehouseId, double quantityInQuintals) async {
    final index = _warehouses.indexWhere((w) => w.warehouseId == warehouseId);
    if (index != -1) {
      final current = _warehouses[index];
      final newAvailable = (current.availableCapacity - quantityInQuintals).clamp(0.0, current.totalCapacity);
      _warehouses[index] = current.copyWith(availableCapacity: newAvailable);
    }
  }
}
