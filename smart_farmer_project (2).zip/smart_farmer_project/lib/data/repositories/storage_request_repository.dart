import 'package:uuid/uuid.dart';
import '../../models/storage_request_model.dart';
import '../datasources/demo_data.dart';
import 'warehouse_repository.dart';

class StorageRequestRepository {
  final List<StorageRequestModel> _requests = [];
  final WarehouseRepository _warehouseRepository;
  final _uuid = const Uuid();

  StorageRequestRepository(this._warehouseRepository) {
    _requests.addAll(DemoData.getDemoStorageRequests());
  }

  Future<List<StorageRequestModel>> getFarmerRequests(String farmerId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _requests.where((r) => r.farmerId == farmerId || r.farmerId == 'demo_farmer_1').toList();
  }

  Future<List<StorageRequestModel>> getWarehouseRequests(String ownerId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _requests.where((r) => r.warehouseOwnerId == ownerId || r.warehouseOwnerId == 'demo_owner_1').toList();
  }

  Future<StorageRequestModel> submitEnquiry({
    required String farmerId,
    required String farmerName,
    required String farmerContact,
    required String warehouseId,
    required String warehouseOwnerId,
    required String warehouseName,
    required String cropName,
    required double quantity,
    required String unit,
    required int durationMonths,
    required String preferredStorageType,
    String? additionalNotes,
  }) async {
    await Future.delayed(const Duration(milliseconds: 400));

    final newRequest = StorageRequestModel(
      requestId: 'req_${_uuid.v4().substring(0, 8)}',
      farmerId: farmerId,
      farmerName: farmerName,
      farmerContact: farmerContact,
      warehouseId: warehouseId,
      warehouseOwnerId: warehouseOwnerId,
      warehouseName: warehouseName,
      cropName: cropName,
      quantity: quantity,
      unit: unit,
      durationMonths: durationMonths,
      preferredStorageType: preferredStorageType,
      additionalNotes: additionalNotes,
      status: 'Pending',
    );

    _requests.insert(0, newRequest);
    return newRequest;
  }

  Future<StorageRequestModel> updateStatus({
    required String requestId,
    required String newStatus, // 'Accepted', 'Rejected', 'Cancelled', 'Completed'
  }) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _requests.indexWhere((r) => r.requestId == requestId);
    if (index == -1) throw Exception('Request not found');

    final existing = _requests[index];
    final updated = existing.copyWith(status: newStatus, updatedAt: DateTime.now());
    _requests[index] = updated;

    // If accepted, atomically check and adjust warehouse available capacity
    if (newStatus == 'Accepted') {
      await _warehouseRepository.adjustCapacityForAcceptedRequest(existing.warehouseId, existing.quantity);
    }

    return updated;
  }
}
