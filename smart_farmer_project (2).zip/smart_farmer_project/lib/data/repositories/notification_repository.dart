import '../../models/notification_model.dart';
import '../datasources/demo_data.dart';

class NotificationRepository {
  final List<AppNotification> _notifications = [];

  NotificationRepository() {
    // Initial sample notifications for demo accounts
    _notifications.addAll(DemoData.getDemoNotifications('demo_farmer_1', 'farmer'));
  }

  Future<List<AppNotification>> getNotifications(String userId, String role) async {
    await Future.delayed(const Duration(milliseconds: 150));
    return _notifications;
  }

  int getUnreadCount() {
    return _notifications.where((n) => !n.isRead).length;
  }

  void markAsRead(String id) {
    final index = _notifications.indexWhere((n) => n.id == id);
    if (index != -1) {
      _notifications[index] = _notifications[index].copyWith(isRead: true);
    }
  }

  void markAllAsRead() {
    for (int i = 0; i < _notifications.length; i++) {
      _notifications[i] = _notifications[i].copyWith(isRead: true);
    }
  }
}
