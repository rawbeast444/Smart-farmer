import '../../models/weather_model.dart';
import '../../core/services/weather_api_service.dart';

class WeatherRepository {
  final WeatherApiService _apiService;

  WeatherRepository({WeatherApiService? apiService})
      : _apiService = apiService ?? OpenWeatherMapService();

  Future<WeatherModel> getWeather({String location = 'Sangli, Maharashtra'}) async {
    return await _apiService.fetchWeatherForLocation(location);
  }
}
