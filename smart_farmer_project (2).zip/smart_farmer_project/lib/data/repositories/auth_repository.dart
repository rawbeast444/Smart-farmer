import '../../models/user_model.dart';
import '../datasources/demo_data.dart';

class AuthRepository {
  AppUser? _currentUser;
  bool _isDemoMode = true;

  AppUser? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  bool get isDemoMode => _isDemoMode;

  AuthRepository() {
    // Auto-login with Demo Farmer for friction-free initial exploration
    _currentUser = DemoData.demoFarmer;
  }

  Future<AppUser> login({
    required String emailOrPhone,
    required String password,
    required String role,
  }) async {
    await Future.delayed(const Duration(milliseconds: 600));

    // Demo Mode checks
    if (role == 'farmer') {
      if (emailOrPhone.contains('rahul') || emailOrPhone == '9822012345' || emailOrPhone.isEmpty) {
        _currentUser = DemoData.demoFarmer;
        return _currentUser!;
      }
    } else {
      if (emailOrPhone.contains('suresh') || emailOrPhone == '9422098765' || emailOrPhone.isEmpty) {
        _currentUser = DemoData.demoWarehouseOwner;
        return _currentUser!;
      }
    }

    // Dynamic mock login for any other credentials entered by tester
    _currentUser = AppUser(
      uid: 'user_${DateTime.now().millisecondsSinceEpoch}',
      fullName: emailOrPhone.split('@').first,
      email: emailOrPhone.contains('@') ? emailOrPhone : '$emailOrPhone@smartfarmer.in',
      phone: emailOrPhone.contains('@') ? '9876543210' : emailOrPhone,
      role: role,
      state: 'Maharashtra',
      district: 'Sangli',
      village: 'Local Village',
      pincode: '416416',
      farmName: role == 'farmer' ? 'Kisan Farm' : null,
      businessName: role == 'warehouse_owner' ? 'Kisan Storage Enterprise' : null,
    );
    return _currentUser!;
  }

  Future<AppUser> register({
    required String fullName,
    required String email,
    required String phone,
    required String password,
    required String role,
    required String state,
    required String district,
    required String village,
    required String pincode,
    String? farmName,
    String? farmingExperience,
    List<String> mainCrops = const [],
    String? businessName,
    String? warehouseName,
    String? warehouseAddress,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final newUser = AppUser(
      uid: 'usr_${DateTime.now().millisecondsSinceEpoch}',
      fullName: fullName,
      email: email,
      phone: phone,
      role: role,
      state: state,
      district: district,
      village: village,
      pincode: pincode,
      farmName: farmName,
      farmingExperience: farmingExperience,
      mainCrops: mainCrops,
      businessName: businessName,
      warehouseName: warehouseName,
      warehouseAddress: warehouseAddress,
    );

    _currentUser = newUser;
    return newUser;
  }

  Future<void> switchDemoAccount(String role) async {
    if (role == 'farmer') {
      _currentUser = DemoData.demoFarmer;
    } else {
      _currentUser = DemoData.demoWarehouseOwner;
    }
  }

  Future<void> updateProfile(AppUser updatedUser) async {
    await Future.delayed(const Duration(milliseconds: 400));
    _currentUser = updatedUser;
  }

  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 300));
    _currentUser = null;
  }

  Future<void> resetPassword(String email) async {
    await Future.delayed(const Duration(milliseconds: 500));
    // In real firebase: await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
  }
}
