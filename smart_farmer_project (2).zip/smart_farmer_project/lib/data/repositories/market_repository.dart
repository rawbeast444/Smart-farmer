import '../../models/market_price_model.dart';
import '../../core/utils/calculations.dart';
import '../../core/services/market_api_service.dart';

class MarketComparisonItem {
  final MarketPriceModel market;
  final double grossRevenue;
  final double transportCost;
  final double netValue;
  final double distanceKm;

  MarketComparisonItem({
    required this.market,
    required this.grossRevenue,
    required this.transportCost,
    required this.netValue,
    required this.distanceKm,
  });
}

class MarketRecommendationResult {
  final MarketPriceModel bestMarket;
  final double estimatedNetValue;
  final double estimatedTransportCost;
  final String reasoning;
  final List<MarketComparisonItem> rankedMarkets;

  MarketRecommendationResult({
    required this.bestMarket,
    required this.estimatedNetValue,
    required this.estimatedTransportCost,
    required this.reasoning,
    required this.rankedMarkets,
  });
}

class MarketRepository {
  final MarketApiService _apiService;

  MarketRepository({MarketApiService? apiService})
      : _apiService = apiService ?? AgmarknetApiService();

  Future<List<MarketPriceModel>> getMarkets({
    String? cropName,
    String? district,
    String? searchQuery,
    String sortBy = 'Nearest Market',
  }) async {
    final list = await _apiService.getMarketPrices(cropName: cropName, district: district);
    
    var filtered = list;
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final q = searchQuery.toLowerCase().trim();
      filtered = filtered.where((m) =>
          m.marketName.toLowerCase().contains(q) ||
          m.cropName.toLowerCase().contains(q) ||
          m.district.toLowerCase().contains(q) ||
          m.city.toLowerCase().contains(q)).toList();
    }

    // Apply Sorting
    switch (sortBy) {
      case 'Highest Average Price':
        filtered.sort((a, b) => b.averagePrice.compareTo(a.averagePrice));
        break;
      case 'Lowest Transportation Cost':
      case 'Nearest Market':
        filtered.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
        break;
      case 'Highest Demand':
        filtered.sort((a, b) => _demandWeight(b.demand).compareTo(_demandWeight(a.demand)));
        break;
      case 'Latest Update':
      default:
        filtered.sort((a, b) => b.lastUpdated.compareTo(a.lastUpdated));
        break;
    }

    return filtered;
  }

  int _demandWeight(String demand) {
    if (demand == 'High') return 3;
    if (demand == 'Moderate') return 2;
    return 1;
  }

  /// Calculates complete market comparison and recommendation for a farmer's crop
  MarketRecommendationResult recommendBestMarket({
    required List<MarketPriceModel> markets,
    required double cropQuantity,
    required String quantityUnit,
  }) {
    if (markets.isEmpty) {
      throw Exception('No markets available for comparison');
    }

    final quantityInQuintals = AgriculturalCalculations.toQuintals(cropQuantity, quantityUnit);

    final comparisonItems = markets.map((m) {
      final transportCost = AgriculturalCalculations.calculateTransportCost(
        quantityInQuintals: quantityInQuintals,
        distanceKm: m.distanceKm,
      );
      final gross = AgriculturalCalculations.calculateGrossRevenue(
        quantityInQuintals: quantityInQuintals,
        pricePerQuintal: m.averagePrice,
      );
      final net = AgriculturalCalculations.calculateNetValue(
        grossRevenue: gross,
        transportCost: transportCost,
      );

      return MarketComparisonItem(
        market: m,
        grossRevenue: gross,
        transportCost: transportCost,
        netValue: net,
        distanceKm: m.distanceKm,
      );
    }).toList();

    // Recommendation Algorithm:
    // We prioritize Estimated Net Value, then factor in Demand and Distance.
    comparisonItems.sort((a, b) {
      // Primary: Net Value
      final netDiff = b.netValue.compareTo(a.netValue);
      if (netDiff != 0) return netDiff;
      // Secondary: Distance
      return a.distanceKm.compareTo(b.distanceKm);
    });

    final best = comparisonItems.first;
    final nearest = comparisonItems.reduce((curr, next) => curr.distanceKm < next.distanceKm ? curr : next);

    String reasoning;
    if (best.market.marketId == nearest.market.marketId) {
      reasoning = '${best.market.marketName} is recommended because it is closest (${best.distanceKm} km) '
          'and yields the highest estimated net return (₹${best.netValue.toStringAsFixed(0)}) with minimal transport expenses.';
    } else {
      final extraProfit = best.netValue - nearest.netValue;
      if (extraProfit > 0) {
        reasoning = '${best.market.marketName} is recommended because despite being ${best.distanceKm} km away, '
            'its higher mandi rate (₹${best.market.averagePrice.toStringAsFixed(0)}/q) offsets transportation costs, '
            'yielding an estimated additional net profit of ₹${extraProfit.toStringAsFixed(0)} over your nearest mandi.';
      } else {
        reasoning = '${best.market.marketName} provides the highest calculated net return after deduction of logistics expenses.';
      }
    }

    return MarketRecommendationResult(
      bestMarket: best.market,
      estimatedNetValue: best.netValue,
      estimatedTransportCost: best.transportCost,
      reasoning: reasoning,
      rankedMarkets: comparisonItems,
    );
  }
}
