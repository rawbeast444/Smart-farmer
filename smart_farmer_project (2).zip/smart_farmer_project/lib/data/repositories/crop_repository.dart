import 'package:uuid/uuid.dart';
import '../../models/crop_model.dart';
import '../datasources/demo_data.dart';

class CropRepository {
  final List<CropModel> _crops = [];
  final _uuid = const Uuid();

  CropRepository() {
    _crops.addAll(DemoData.getInitialCrops());
  }

  Future<List<CropModel>> getFarmerCrops(String farmerId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return List.unmodifiable(_crops.where((c) => c.farmerId == farmerId || c.farmerId == 'demo_farmer_1'));
  }

  Future<CropModel> addCrop({
    required String farmerId,
    required String cropName,
    required double quantity,
    required String unit,
    required DateTime harvestDate,
    required String quality,
    required String condition,
    required String farmerLocation,
    String? additionalNotes,
  }) async {
    await Future.delayed(const Duration(milliseconds: 300));

    final newCrop = CropModel(
      cropId: 'crop_${_uuid.v4().substring(0, 8)}',
      farmerId: farmerId,
      cropName: cropName,
      quantity: quantity,
      unit: unit,
      harvestDate: harvestDate,
      quality: quality,
      condition: condition,
      farmerLocation: farmerLocation,
      additionalNotes: additionalNotes,
    );

    _crops.insert(0, newCrop);
    return newCrop;
  }

  Future<CropModel> updateCrop(CropModel updatedCrop) async {
    await Future.delayed(const Duration(milliseconds: 250));
    final index = _crops.indexWhere((c) => c.cropId == updatedCrop.cropId);
    if (index != -1) {
      _crops[index] = updatedCrop;
      return updatedCrop;
    }
    throw Exception('Crop not found');
  }

  Future<bool> deleteCrop(String cropId) async {
    await Future.delayed(const Duration(milliseconds: 250));
    final index = _crops.indexWhere((c) => c.cropId == cropId);
    if (index != -1) {
      _crops.removeAt(index);
      return true;
    }
    return false;
  }
}
