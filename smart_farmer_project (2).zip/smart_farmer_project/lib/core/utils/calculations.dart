import '../constants/app_constants.dart';

class AgriculturalCalculations {
  /// Converts any quantity to standard Quintals (100 kg)
  static double toQuintals(double quantity, String unit) {
    switch (unit.toLowerCase()) {
      case 'kilograms':
      case 'kilograms (kg)':
      case 'kg':
        return quantity * AppConstants.kgToQuintal;
      case 'tonnes':
      case 'tonnes (t)':
      case 't':
        return quantity * AppConstants.tonneToQuintal;
      case 'quintals':
      case 'quintals (q)':
      case 'q':
      default:
        return quantity;
    }
  }

  /// Calculates estimated transportation cost in INR
  /// Transport Cost = (Rate per Quintal per KM * Distance * Quantity in Quintals) + (Base handling * Quantity)
  static double calculateTransportCost({
    required double quantityInQuintals,
    required double distanceKm,
    double ratePerKmPerQuintal = AppConstants.transportCostPerQuintalPerKm,
  }) {
    if (quantityInQuintals <= 0 || distanceKm <= 0) return 0.0;
    final variableCost = ratePerKmPerQuintal * distanceKm * quantityInQuintals;
    final handlingCost = AppConstants.baseHandlingCostPerQuintal * quantityInQuintals;
    return variableCost + handlingCost;
  }

  /// Calculates Gross Revenue = Quantity in Quintals * Price per Quintal
  static double calculateGrossRevenue({
    required double quantityInQuintals,
    required double pricePerQuintal,
  }) {
    return quantityInQuintals * pricePerQuintal;
  }

  /// Calculates Estimated Net Value = Gross Revenue - Transportation Cost
  static double calculateNetValue({
    required double grossRevenue,
    required double transportCost,
  }) {
    return grossRevenue - transportCost;
  }
}
