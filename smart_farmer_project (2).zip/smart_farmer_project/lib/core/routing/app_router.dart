import 'package:flutter/material.dart';
import '../../models/crop_model.dart';
import '../../models/market_price_model.dart';
import '../../models/warehouse_model.dart';
import '../../models/storage_request_model.dart';
import '../../models/ai_prediction_model.dart';
import '../../data/repositories/market_repository.dart';

import '../../features/onboarding/splash_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/auth/role_selection_screen.dart';
import '../../features/auth/login_screen.dart';
import '../../features/auth/register_screen.dart';
import '../../features/auth/forgot_password_screen.dart';

import '../../features/farmer/farmer_main_screen.dart';
import '../../features/farmer/farmer_dashboard_screen.dart';
import '../../features/farmer/crops/add_crop_screen.dart';
import '../../features/farmer/crops/my_crops_screen.dart';
import '../../features/farmer/crops/crop_details_screen.dart';
import '../../features/farmer/markets/market_search_screen.dart';
import '../../features/farmer/markets/market_details_screen.dart';
import '../../features/farmer/markets/market_comparison_screen.dart';
import '../../features/farmer/markets/market_recommendation_screen.dart';
import '../../features/farmer/markets/market_map_screen.dart';
import '../../features/farmer/warehouses/warehouse_search_screen.dart';
import '../../features/farmer/warehouses/warehouse_details_screen.dart';
import '../../features/farmer/warehouses/storage_enquiry_screen.dart';
import '../../features/farmer/warehouses/my_enquiries_screen.dart';
import '../../features/farmer/ai_assistant/ai_storage_screen.dart';
import '../../features/farmer/ai_assistant/ai_prediction_result_screen.dart';
import '../../features/farmer/weather/weather_screen.dart';
import '../../features/farmer/profile/farmer_profile_screen.dart';
import '../../features/farmer/profile/edit_farmer_profile_screen.dart';

import '../../features/warehouse_owner/warehouse_owner_main_screen.dart';
import '../../features/warehouse_owner/warehouse_dashboard_screen.dart';
import '../../features/warehouse_owner/my_warehouse_screen.dart';
import '../../features/warehouse_owner/edit_warehouse_screen.dart';
import '../../features/warehouse_owner/capacity_management_screen.dart';
import '../../features/warehouse_owner/enquiries_list_screen.dart';
import '../../features/warehouse_owner/enquiry_details_screen.dart';
import '../../features/warehouse_owner/warehouse_owner_profile_screen.dart';

import '../../features/notifications/notifications_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/settings/help_support_screen.dart';
import '../../features/settings/terms_privacy_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case '/onboarding':
        return MaterialPageRoute(builder: (_) => const OnboardingScreen());
      case '/role_selection':
        return MaterialPageRoute(builder: (_) => const RoleSelectionScreen());
      case '/login':
        final role = settings.arguments as String?;
        return MaterialPageRoute(builder: (_) => LoginScreen(initialRole: role));
      case '/register':
        final role = settings.arguments as String?;
        return MaterialPageRoute(builder: (_) => RegisterScreen(initialRole: role));
      case '/forgot_password':
        return MaterialPageRoute(builder: (_) => const ForgotPasswordScreen());

      // Farmer routes
      case '/farmer_main':
        final tab = settings.arguments as int? ?? 0;
        return MaterialPageRoute(builder: (_) => FarmerMainScreen(initialTab: tab));
      case '/farmer_dashboard':
        return MaterialPageRoute(builder: (_) => const FarmerDashboardScreen());
      case '/add_crop':
        return MaterialPageRoute(builder: (_) => const AddCropScreen());
      case '/my_crops':
        return MaterialPageRoute(builder: (_) => const MyCropsScreen());
      case '/crop_details':
        final crop = settings.arguments as CropModel;
        return MaterialPageRoute(builder: (_) => CropDetailsScreen(crop: crop));
      case '/market_search':
        final query = settings.arguments as String?;
        return MaterialPageRoute(builder: (_) => MarketSearchScreen(initialQuery: query));
      case '/market_details':
        final market = settings.arguments as MarketPriceModel;
        return MaterialPageRoute(builder: (_) => MarketDetailsScreen(market: market));
      case '/market_comparison':
        final markets = settings.arguments as List<MarketPriceModel>;
        return MaterialPageRoute(builder: (_) => MarketComparisonScreen(markets: markets));
      case '/market_recommendation':
        final rec = settings.arguments as MarketRecommendationResult;
        return MaterialPageRoute(builder: (_) => MarketRecommendationScreen(recommendation: rec));
      case '/market_map':
        final market = settings.arguments as MarketPriceModel?;
        return MaterialPageRoute(builder: (_) => MarketMapScreen(focusedMarket: market));
      case '/warehouse_search':
        return MaterialPageRoute(builder: (_) => const WarehouseSearchScreen());
      case '/warehouse_details':
        final wh = settings.arguments as WarehouseModel;
        return MaterialPageRoute(builder: (_) => WarehouseDetailsScreen(warehouse: wh));
      case '/storage_enquiry':
        final wh = settings.arguments as WarehouseModel;
        return MaterialPageRoute(builder: (_) => StorageEnquiryScreen(warehouse: wh));
      case '/my_enquiries':
        return MaterialPageRoute(builder: (_) => const MyEnquiriesScreen());
      case '/ai_storage':
        final crop = settings.arguments as CropModel?;
        return MaterialPageRoute(builder: (_) => AIStorageScreen(preselectedCrop: crop));
      case '/ai_prediction_result':
        final result = settings.arguments as AIPredictionResult;
        return MaterialPageRoute(builder: (_) => AIPredictionResultScreen(result: result));
      case '/weather':
        return MaterialPageRoute(builder: (_) => const WeatherScreen());
      case '/profile':
        return MaterialPageRoute(builder: (_) => const FarmerProfileScreen());
      case '/edit_farmer_profile':
        return MaterialPageRoute(builder: (_) => const EditFarmerProfileScreen());

      // Warehouse Owner routes
      case '/warehouse_main':
        final tab = settings.arguments as int? ?? 0;
        return MaterialPageRoute(builder: (_) => WarehouseOwnerMainScreen(initialTab: tab));
      case '/warehouse_dashboard':
        return MaterialPageRoute(builder: (_) => const WarehouseDashboardScreen());
      case '/my_warehouse':
        return MaterialPageRoute(builder: (_) => const MyWarehouseScreen());
      case '/edit_warehouse':
        final wh = settings.arguments as WarehouseModel;
        return MaterialPageRoute(builder: (_) => EditWarehouseScreen(warehouse: wh));
      case '/capacity_management':
        return MaterialPageRoute(builder: (_) => const CapacityManagementScreen());
      case '/enquiries_list':
        return MaterialPageRoute(builder: (_) => const EnquiriesListScreen());
      case '/enquiry_details':
        final req = settings.arguments as StorageRequestModel;
        return MaterialPageRoute(builder: (_) => EnquiryDetailsScreen(enquiry: req));
      case '/warehouse_profile':
        return MaterialPageRoute(builder: (_) => const WarehouseOwnerProfileScreen());

      // Shared
      case '/notifications':
        return MaterialPageRoute(builder: (_) => const NotificationsScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      case '/help_support':
        return MaterialPageRoute(builder: (_) => const HelpSupportScreen());
      case '/terms_privacy':
        return MaterialPageRoute(builder: (_) => const TermsPrivacyScreen());

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('Route Not Found')),
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}
