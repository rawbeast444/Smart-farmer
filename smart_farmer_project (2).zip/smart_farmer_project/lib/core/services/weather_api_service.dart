import '../../models/weather_model.dart';
import '../../data/datasources/demo_data.dart';

abstract class WeatherApiService {
  Future<WeatherModel> fetchWeatherForLocation(String location);
}

/// Extensible Weather API client prepared for OpenWeatherMap / IMD API integration.
class OpenWeatherMapService implements WeatherApiService {
  final String? apiKey;
  final bool isLive;

  OpenWeatherMapService({this.apiKey, this.isLive = false});

  @override
  Future<WeatherModel> fetchWeatherForLocation(String location) async {
    if (isLive && apiKey != null && apiKey!.isNotEmpty) {
      // Future integration point: OpenWeatherMap OneCall API
      // https://api.openweathermap.org/data/2.5/weather?q=$location&appid=$apiKey&units=metric
      return DemoData.getDemoWeather(location: location);
    } else {
      await Future.delayed(const Duration(milliseconds: 250));
      return DemoData.getDemoWeather(location: location);
    }
  }
}
