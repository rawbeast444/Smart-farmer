import '../constants/app_strings.dart';
import '../../models/ai_prediction_model.dart';

/// Transparent crop-specific rule engine backed by Indian Agricultural Research (ICAR / NHB) benchmarks.
class AICropStorageService {
  /// Evaluates storage life and spoilage risk
  static AIPredictionResult predictStorageLife({
    required String cropName,
    String? variety,
    required String quality,
    required String condition,
    required DateTime harvestDate,
    required double quantity,
    required String storageType,
    required double currentTemp,
    required double currentHumidity,
    required String packagingType,
  }) {
    // Days already elapsed since harvest
    final elapsedDays = DateTime.now().difference(harvestDate).inDays.clamp(0, 365);

    // Baseline reference range based on crop and storage method
    double baseStorageDays = _getBaseStorageDays(cropName, storageType);
    
    // Quality adjustment factor
    double qualityFactor = 1.0;
    if (quality == AppStrings.qualityPremium) qualityFactor = 1.15;
    else if (quality == AppStrings.qualityGood) qualityFactor = 1.0;
    else if (quality == AppStrings.qualityAverage) qualityFactor = 0.8;
    else if (quality == AppStrings.qualityPoor) qualityFactor = 0.5;

    // Condition adjustment factor
    double conditionFactor = 1.0;
    if (condition == AppStrings.conditionFresh) conditionFactor = 1.0;
    else if (condition == AppStrings.conditionSlightlyDamaged) conditionFactor = 0.7;
    else if (condition == AppStrings.conditionDamaged) conditionFactor = 0.4;

    // Storage type suitability factor
    final optimalStorage = _getOptimalStorageType(cropName);
    double storageSuitabilityFactor = 1.0;
    if (storageType == optimalStorage) {
      storageSuitabilityFactor = 1.1;
    } else if (storageType == AppStrings.storageNormal && optimalStorage == AppStrings.storageCold) {
      storageSuitabilityFactor = 0.35; // Major penalty storing perishable in room temperature
    }

    // Packaging factor
    double packagingFactor = 1.0;
    if (packagingType.contains('Crates') || packagingType.contains('Jute')) {
      packagingFactor = 1.05; // Good aeration
    } else if (packagingType.contains('Plastic') || packagingType.contains('Airtight')) {
      if (cropName == 'Tomato' || cropName == 'Chilli') {
        packagingFactor = 0.85; // Moisture condensation traps rot
      }
    }

    final totalEstimatedDays = (baseStorageDays * qualityFactor * conditionFactor * storageSuitabilityFactor * packagingFactor).roundToDouble();
    final remainingDays = (totalEstimatedDays - elapsedDays).clamp(0.0, totalEstimatedDays);

    // Risk classification
    String risk;
    if (remainingDays <= 3 || condition == AppStrings.conditionDamaged) {
      risk = 'High Risk';
    } else if (remainingDays <= 12 || condition == AppStrings.conditionSlightlyDamaged) {
      risk = 'Medium Risk';
    } else {
      risk = 'Low Risk';
    }

    final reference = _getCropReference(cropName);

    return AIPredictionResult(
      cropName: cropName,
      variety: variety,
      storageType: storageType,
      estimatedStorageDays: totalEstimatedDays,
      remainingStorageDays: remainingDays,
      spoilageRisk: risk,
      recommendedTemp: reference.recommendedTemp,
      recommendedHumidity: reference.recommendedHumidity,
      recommendedConditions: reference.recommendedConditions,
      coldStorageAdvised: optimalStorage == AppStrings.storageCold || optimalStorage == AppStrings.storageCA,
      handlingInstructions: reference.handlingInstructions,
      warnings: _generateWarnings(cropName, storageType, condition, elapsedDays, remainingDays),
      explanation: 'Estimated storage of ~${totalEstimatedDays.toInt()} days based on $quality quality, $condition condition, and $storageType. '
          '$elapsedDays days have passed since harvest. Recommended conditions are ${reference.recommendedTemp} and ${reference.recommendedHumidity}.',
    );
  }

  static double _getBaseStorageDays(String crop, String storageType) {
    switch (crop) {
      case 'Tomato':
        if (storageType == AppStrings.storageCold) return 28.0;
        if (storageType == AppStrings.storageCA) return 35.0;
        return 7.0; // Normal ambient
      case 'Onion':
        if (storageType == AppStrings.storageCold) return 180.0;
        if (storageType == AppStrings.storageDry) return 120.0;
        return 60.0;
      case 'Potato':
        if (storageType == AppStrings.storageCold) return 210.0;
        return 45.0;
      case 'Wheat':
        if (storageType == AppStrings.storageDry || storageType == AppStrings.storageNormal) return 365.0;
        return 365.0;
      case 'Rice':
        return 365.0;
      case 'Soybean':
        if (storageType == AppStrings.storageDry) return 240.0;
        return 120.0;
      case 'Cotton':
        return 300.0;
      case 'Chilli':
        if (storageType == AppStrings.storageCold) return 30.0;
        if (storageType == AppStrings.storageDry) return 180.0; // Dry red chilli
        return 10.0;
      case 'Sugarcane':
        return 4.0; // Highly perishable sucrose inversion
      default:
        return 30.0;
    }
  }

  static String _getOptimalStorageType(String crop) {
    switch (crop) {
      case 'Tomato':
      case 'Potato':
        return AppStrings.storageCold;
      case 'Onion':
      case 'Chilli':
      case 'Wheat':
      case 'Rice':
      case 'Soybean':
      case 'Cotton':
        return AppStrings.storageDry;
      default:
        return AppStrings.storageNormal;
    }
  }

  static _CropStorageRef _getCropReference(String crop) {
    switch (crop) {
      case 'Tomato':
        return _CropStorageRef(
          recommendedTemp: '10°C to 13°C (Do not freeze below 7°C)',
          recommendedHumidity: '85% – 90% RH',
          recommendedConditions: 'Well-ventilated plastic crates. Avoid stack heights above 4 layers to prevent crushing.',
          handlingInstructions: [
            'Harvest at mature-green to breaker stage for extended transit and storage.',
            'Keep out of direct sunlight and rain immediately after picking.',
            'Store away from ethylene-emitting fruits if room cooling.',
          ],
        );
      case 'Onion':
        return _CropStorageRef(
          recommendedTemp: '0°C to 2°C (Cold) or 25°C - 30°C with good aeration (Dry)',
          recommendedHumidity: '65% – 70% RH (Keep dry to prevent sprouting)',
          recommendedConditions: 'Slotted bamboo racks or aerated net bags. Low humidity is critical.',
          handlingInstructions: [
            'Ensure proper field curing for 10-14 days until neck is completely dry.',
            'Cull thick-neck and damaged bulbs prior to loading.',
            'Never store alongside potatoes (cross-moisture causes fungal rot).',
          ],
        );
      case 'Potato':
        return _CropStorageRef(
          recommendedTemp: '8°C to 12°C with CIPC treatment or 2°C to 4°C for seed',
          recommendedHumidity: '90% – 95% RH',
          recommendedConditions: 'Dark, well-ventilated cold room. Light exposure causes greening (solanine).',
          handlingInstructions: [
            'Pre-condition and cure skins at 15°C for 10 days before cold storage.',
            'Prevent rough handling that bruises or punctures tuber skin.',
          ],
        );
      case 'Wheat':
      case 'Rice':
        return _CropStorageRef(
          recommendedTemp: 'Ambient dry conditions (below 25°C preferred)',
          recommendedHumidity: 'Moisture content strictly under 12%',
          recommendedConditions: 'Elevated wooden pallets in dry dunnage warehouse, protected from rodents and weevils.',
          handlingInstructions: [
            'Ensure grain moisture is below 12% before bagging.',
            'Fumigate using certified phosphine protocols if storing above 3 months.',
          ],
        );
      case 'Soybean':
        return _CropStorageRef(
          recommendedTemp: 'Ambient cool, well-ventilated',
          recommendedHumidity: 'Safe seed moisture 10% – 11%',
          recommendedConditions: 'Dry godown storage with moisture-proof dunnage.',
          handlingInstructions: [
            'Avoid bag dropping; soybean seed coats crack easily.',
            'Maintain periodic checks for mold and oil oxidation.',
          ],
        );
      default:
        return _CropStorageRef(
          recommendedTemp: 'Ambient to cool (15°C - 20°C)',
          recommendedHumidity: '65% - 75% RH',
          recommendedConditions: 'Clean, dry and elevated surface.',
          handlingInstructions: [
            'Inspect crops regularly for signs of fungal or pest infestation.',
            'Maintain dry surroundings and proper air circulation.',
          ],
        );
    }
  }

  static List<String> _generateWarnings(String crop, String storage, String condition, int elapsed, double remaining) {
    final list = <String>[];
    if (remaining <= 3) {
      list.add('URGENT: Harvest is near the end of safe storage window. Recommend immediate sale in local mandi.');
    }
    if (condition == AppStrings.conditionDamaged) {
      list.add('Damaged crops rot 3x faster. Isolate affected produce to prevent contamination of healthy batch.');
    }
    if (crop == 'Tomato' && storage == AppStrings.storageNormal) {
      list.add('Tomatoes deteriorate rapidly at ambient Indian summer temperatures. Cold storage recommended.');
    }
    if (crop == 'Onion' && storage == AppStrings.storageCold) {
      list.add('Cold-stored onions must be de-sweated (gradually warmed) before taking to market to avoid mold.');
    }
    return list;
  }
}

class _CropStorageRef {
  final String recommendedTemp;
  final String recommendedHumidity;
  final String recommendedConditions;
  final List<String> handlingInstructions;

  _CropStorageRef({
    required this.recommendedTemp,
    required this.recommendedHumidity,
    required this.recommendedConditions,
    required this.handlingInstructions,
  });
}
