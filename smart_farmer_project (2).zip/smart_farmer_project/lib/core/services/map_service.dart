import 'dart:math' as math;

class LocationCoordinate {
  final double latitude;
  final double longitude;
  final String name;

  const LocationCoordinate(this.latitude, this.longitude, this.name);
}

class MapService {
  // Known Maharashtra Agriculture Centres coordinates
  static const Map<String, LocationCoordinate> mandiCoordinates = {
    'Sangli APMC Mandi': LocationCoordinate(16.8524, 74.5815, 'Sangli APMC'),
    'Kolhapur APMC (Shahu Market)': LocationCoordinate(16.7050, 74.2433, 'Kolhapur APMC'),
    'Pune APMC (Gultekdi)': LocationCoordinate(18.4967, 73.8647, 'Pune APMC'),
    'Nashik APMC Mandi': LocationCoordinate(19.9975, 73.7898, 'Nashik APMC'),
    'Lasalgaon APMC (Asia Largest Onion Market)': LocationCoordinate(20.1472, 74.2256, 'Lasalgaon APMC'),
    'Solapur APMC Mandi': LocationCoordinate(17.6599, 75.9064, 'Solapur APMC'),
    'Satara APMC Mandi': LocationCoordinate(17.6805, 73.9934, 'Satara APMC'),
    'Miraj Modern Agro Cold Storage': LocationCoordinate(16.8272, 74.6467, 'Miraj Cold Storage'),
    'Krishna Valley Agro Warehouse': LocationCoordinate(17.0345, 74.5982, 'Krishna Valley'),
  };

  /// Calculates Haversine distance in KM between two geographic points
  static double calculateDistanceKm({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    const double p = 0.017453292519943295; // Math.PI / 180
    final double a = 0.5 -
        math.cos((lat2 - lat1) * p) / 2 +
        math.cos(lat1 * p) * math.cos(lat2 * p) * (1 - math.cos((lon2 - lon1) * p)) / 2;
    return 12742 * math.asin(math.sqrt(a)); // 2 * R * asin...
  }

  /// Estimates travel duration in minutes based on rural/highway road factors
  static int estimateTravelTimeMinutes(double distanceKm) {
    // Average freight speed in rural Maharashtra ~ 35 km/h
    return ((distanceKm / 35.0) * 60).round();
  }
}
