import '../../models/market_price_model.dart';
import '../../data/datasources/demo_data.dart';

abstract class MarketApiService {
  Future<List<MarketPriceModel>> getMarketPrices({String? cropName, String? district});
}

/// Service layer architecture ready for live AGMARKNET / e-NAM integration.
/// When live API keys or endpoints are unavailable, gracefully serves labeled DEMO DATA.
class AgmarknetApiService implements MarketApiService {
  final bool useLiveApi;
  final String? apiKey;

  AgmarknetApiService({this.useLiveApi = false, this.apiKey});

  @override
  Future<List<MarketPriceModel>> getMarketPrices({String? cropName, String? district}) async {
    if (useLiveApi && apiKey != null && apiKey!.isNotEmpty) {
      // Future integration point: HTTP call to AGMARKNET / e-NAM API
      // Example: https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070
      try {
        // Implement real HTTP request here
        throw UnimplementedError('Live API credentials not yet provisioned');
      } catch (e) {
        // Fallback to demo data with demo flags
        return _fetchDemoPrices(cropName: cropName, district: district);
      }
    } else {
      // Instant reliable demo dataset for Maharashtra mandis
      await Future.delayed(const Duration(milliseconds: 300)); // Simulate network latency
      return _fetchDemoPrices(cropName: cropName, district: district);
    }
  }

  List<MarketPriceModel> _fetchDemoPrices({String? cropName, String? district}) {
    var list = DemoData.getDemoMarketPrices();
    if (cropName != null && cropName.isNotEmpty && cropName != 'All') {
      list = list.where((m) => m.cropName.toLowerCase() == cropName.toLowerCase()).toList();
    }
    if (district != null && district.isNotEmpty && district != 'All') {
      list = list.where((m) => m.district.toLowerCase() == district.toLowerCase()).toList();
    }
    return list;
  }
}
