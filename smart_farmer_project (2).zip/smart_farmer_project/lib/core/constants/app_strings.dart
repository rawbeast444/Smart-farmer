class AppStrings {
  static const String appName = 'SMART FARMER';
  static const String appTagline = 'Smart Decisions. Better Harvests.';
  static const String demoBadge = 'DEMO DATA – NOT LIVE MARKET PRICES';
  static const String demoNoticeShort = 'DEMO DATA';
  
  // Roles
  static const String roleFarmer = 'farmer';
  static const String roleWarehouseOwner = 'warehouse_owner';
  
  // Storage Types
  static const String storageCold = 'Cold Storage';
  static const String storageNormal = 'Normal Storage';
  static const String storageCA = 'Controlled Atmosphere (CA)';
  static const String storageDry = 'Dry Storage';
  
  // Crop Units
  static const String unitKg = 'Kilograms (kg)';
  static const String unitQuintal = 'Quintals (q)';
  static const String unitTonne = 'Tonnes (t)';
  
  // Quality & Condition
  static const String qualityPremium = 'Premium';
  static const String qualityGood = 'Good';
  static const String qualityAverage = 'Average';
  static const String qualityPoor = 'Poor';

  static const String conditionFresh = 'Freshly Harvested';
  static const String conditionSlightlyDamaged = 'Slightly Damaged';
  static const String conditionDamaged = 'Damaged';

  // AI Disclaimer
  static const String aiDisclaimer =
      'These predictions are estimates, not guarantees. Actual storage life depends on crop variety, harvesting conditions, handling, temperature, humidity and storage infrastructure. Consult an agricultural expert for critical decisions.';
}
