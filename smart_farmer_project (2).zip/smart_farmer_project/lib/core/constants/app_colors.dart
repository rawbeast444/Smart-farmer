import 'package:flutter/material.dart';

class AppColors {
  // Brand Theme Colors
  static const Color primary = Color(0xFF1B5E20);      // Deep Agriculture Green
  static const Color primaryDark = Color(0xFF003300);  // Dark shade
  static const Color secondary = Color(0xFF4CAF50);    // Fresh Green
  static const Color accent = Color(0xFFA5D6A7);       // Light Green
  
  // Surfaces & Backgrounds
  static const Color background = Color(0xFFF8FAF5);   // Off White / Agriculture Tint
  static const Color surface = Color(0xFFFFFFFF);      // Clean Pure White
  static const Color surfaceVariant = Color(0xFFF0F4EC); // Light Card Tint
  
  // Typography & Neutrals
  static const Color textPrimary = Color(0xFF1A2E1C);  // Deep Charcoal Green
  static const Color textSecondary = Color(0xFF556857);// Muted Forest Grey
  static const Color textLight = Color(0xFF88998A);    // Subtle Label Tint
  static const Color divider = Color(0xFFE2E8DE);      // Soft Card Border
  
  // Feedback & Status
  static const Color error = Color(0xFFD32F2F);        // Vibrant Red
  static const Color warning = Color(0xFFFFA000);      // Amber
  static const Color success = Color(0xFF2E7D32);      // Vibrant Green
  static const Color info = Color(0xFF1976D2);         // Informational Blue
  
  // Demo Mode Banner
  static const Color demoBannerBg = Color(0xFFFFF3E0); // Soft Amber
  static const Color demoBannerText = Color(0xFFE65100); // Deep Orange
}
