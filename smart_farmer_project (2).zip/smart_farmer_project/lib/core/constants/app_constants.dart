class AppConstants {
  // Unit conversion factors to Quintals (standard wholesale market unit)
  static const double kgToQuintal = 0.01;
  static const double tonneToQuintal = 10.0;
  static const double quintalToKg = 100.0;
  
  // Standard Transport Cost Estimation: ₹ per quintal per KM (Indian rural logistics baseline)
  static const double transportCostPerQuintalPerKm = 2.5; 
  static const double baseHandlingCostPerQuintal = 15.0; // loading/unloading
  
  // Maharashtra Focus Districts
  static const List<String> maharashtraDistricts = [
    'Sangli',
    'Kolhapur',
    'Pune',
    'Nashik',
    'Satara',
    'Solapur',
    'Ahmednagar',
    'Nagpur',
    'Aurangabad (Chhatrapati Sambhajinagar)',
    'Jalgaon',
  ];
  
  // Target Crops
  static const List<String> supportedCrops = [
    'Tomato',
    'Onion',
    'Potato',
    'Wheat',
    'Rice',
    'Soybean',
    'Cotton',
    'Sugarcane',
    'Chilli',
  ];
}
