class AppUser {
  final String uid;
  final String fullName;
  final String email;
  final String phone;
  final String role; // 'farmer' or 'warehouse_owner'
  final String state;
  final String district;
  final String village;
  final String pincode;
  
  // Farmer specific fields
  final String? farmName;
  final String? farmingExperience;
  final List<String> mainCrops;
  
  // Warehouse Owner specific fields
  final String? businessName;
  final String? warehouseName;
  final String? warehouseAddress;

  final DateTime createdAt;
  final DateTime updatedAt;

  AppUser({
    required this.uid,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.role,
    required this.state,
    required this.district,
    required this.village,
    required this.pincode,
    this.farmName,
    this.farmingExperience,
    this.mainCrops = const [],
    this.businessName,
    this.warehouseName,
    this.warehouseAddress,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  bool get isFarmer => role == 'farmer';
  bool get isWarehouseOwner => role == 'warehouse_owner';

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'fullName': fullName,
      'email': email,
      'phone': phone,
      'role': role,
      'state': state,
      'district': district,
      'village': village,
      'pincode': pincode,
      'farmName': farmName,
      'farmingExperience': farmingExperience,
      'mainCrops': mainCrops,
      'businessName': businessName,
      'warehouseName': warehouseName,
      'warehouseAddress': warehouseAddress,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory AppUser.fromMap(Map<String, dynamic> map, {String? id}) {
    return AppUser(
      uid: id ?? map['uid'] ?? '',
      fullName: map['fullName'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      role: map['role'] ?? 'farmer',
      state: map['state'] ?? 'Maharashtra',
      district: map['district'] ?? 'Sangli',
      village: map['village'] ?? '',
      pincode: map['pincode'] ?? '',
      farmName: map['farmName'],
      farmingExperience: map['farmingExperience'],
      mainCrops: List<String>.from(map['mainCrops'] ?? []),
      businessName: map['businessName'],
      warehouseName: map['warehouseName'],
      warehouseAddress: map['warehouseAddress'],
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : DateTime.now(),
    );
  }

  AppUser copyWith({
    String? fullName,
    String? email,
    String? phone,
    String? state,
    String? district,
    String? village,
    String? pincode,
    String? farmName,
    String? farmingExperience,
    List<String>? mainCrops,
    String? businessName,
    String? warehouseName,
    String? warehouseAddress,
  }) {
    return AppUser(
      uid: uid,
      fullName: fullName ?? this.fullName,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      role: role,
      state: state ?? this.state,
      district: district ?? this.district,
      village: village ?? this.village,
      pincode: pincode ?? this.pincode,
      farmName: farmName ?? this.farmName,
      farmingExperience: farmingExperience ?? this.farmingExperience,
      mainCrops: mainCrops ?? this.mainCrops,
      businessName: businessName ?? this.businessName,
      warehouseName: warehouseName ?? this.warehouseName,
      warehouseAddress: warehouseAddress ?? this.warehouseAddress,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
