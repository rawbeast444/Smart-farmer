class MarketPriceModel {
  final String marketId;
  final String marketName;
  final String state;
  final String district;
  final String city;
  final String cropName;
  final double minPrice; // ₹ per quintal
  final double maxPrice; // ₹ per quintal
  final double averagePrice; // ₹ per quintal
  final String demand; // 'High', 'Moderate', 'Low'
  final double distanceKm;
  final DateTime lastUpdated;
  final String dataSource;
  final bool isDemo;
  final String priceUnit;

  MarketPriceModel({
    required this.marketId,
    required this.marketName,
    required this.state,
    required this.district,
    required this.city,
    required this.cropName,
    required this.minPrice,
    required this.maxPrice,
    required this.averagePrice,
    required this.demand,
    required this.distanceKm,
    required this.lastUpdated,
    this.dataSource = 'AGMARKNET (Demo Mode)',
    this.isDemo = true,
    this.priceUnit = '₹/quintal',
  });

  Map<String, dynamic> toMap() {
    return {
      'marketId': marketId,
      'marketName': marketName,
      'state': state,
      'district': district,
      'city': city,
      'cropName': cropName,
      'minPrice': minPrice,
      'maxPrice': maxPrice,
      'averagePrice': averagePrice,
      'demand': demand,
      'distanceKm': distanceKm,
      'lastUpdated': lastUpdated.toIso8601String(),
      'dataSource': dataSource,
      'isDemo': isDemo,
      'priceUnit': priceUnit,
    };
  }

  factory MarketPriceModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return MarketPriceModel(
      marketId: id ?? map['marketId'] ?? '',
      marketName: map['marketName'] ?? '',
      state: map['state'] ?? 'Maharashtra',
      district: map['district'] ?? '',
      city: map['city'] ?? '',
      cropName: map['cropName'] ?? '',
      minPrice: (map['minPrice'] as num?)?.toDouble() ?? 0.0,
      maxPrice: (map['maxPrice'] as num?)?.toDouble() ?? 0.0,
      averagePrice: (map['averagePrice'] as num?)?.toDouble() ?? 0.0,
      demand: map['demand'] ?? 'Moderate',
      distanceKm: (map['distanceKm'] as num?)?.toDouble() ?? 0.0,
      lastUpdated: map['lastUpdated'] != null ? DateTime.parse(map['lastUpdated']) : DateTime.now(),
      dataSource: map['dataSource'] ?? 'AGMARKNET (Demo Mode)',
      isDemo: map['isDemo'] ?? true,
      priceUnit: map['priceUnit'] ?? '₹/quintal',
    );
  }
}
