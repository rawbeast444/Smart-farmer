class CropModel {
  final String cropId;
  final String farmerId;
  final String cropName;
  final double quantity;
  final String unit; // 'Kilograms (kg)', 'Quintals (q)', 'Tonnes (t)'
  final DateTime harvestDate;
  final String quality; // 'Premium', 'Good', 'Average', 'Poor'
  final String condition; // 'Freshly Harvested', 'Slightly Damaged', 'Damaged'
  final String farmerLocation;
  final String? additionalNotes;
  final DateTime createdAt;

  CropModel({
    required this.cropId,
    required this.farmerId,
    required this.cropName,
    required this.quantity,
    required this.unit,
    required this.harvestDate,
    required this.quality,
    required this.condition,
    required this.farmerLocation,
    this.additionalNotes,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'cropId': cropId,
      'farmerId': farmerId,
      'cropName': cropName,
      'quantity': quantity,
      'unit': unit,
      'harvestDate': harvestDate.toIso8601String(),
      'quality': quality,
      'condition': condition,
      'farmerLocation': farmerLocation,
      'additionalNotes': additionalNotes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory CropModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return CropModel(
      cropId: id ?? map['cropId'] ?? '',
      farmerId: map['farmerId'] ?? '',
      cropName: map['cropName'] ?? '',
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0.0,
      unit: map['unit'] ?? 'Quintals (q)',
      harvestDate: map['harvestDate'] != null ? DateTime.parse(map['harvestDate']) : DateTime.now(),
      quality: map['quality'] ?? 'Good',
      condition: map['condition'] ?? 'Freshly Harvested',
      farmerLocation: map['farmerLocation'] ?? '',
      additionalNotes: map['additionalNotes'],
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
    );
  }

  CropModel copyWith({
    String? cropName,
    double? quantity,
    String? unit,
    DateTime? harvestDate,
    String? quality,
    String? condition,
    String? farmerLocation,
    String? additionalNotes,
  }) {
    return CropModel(
      cropId: cropId,
      farmerId: farmerId,
      cropName: cropName ?? this.cropName,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      harvestDate: harvestDate ?? this.harvestDate,
      quality: quality ?? this.quality,
      condition: condition ?? this.condition,
      farmerLocation: farmerLocation ?? this.farmerLocation,
      additionalNotes: additionalNotes ?? this.additionalNotes,
      createdAt: createdAt,
    );
  }
}
