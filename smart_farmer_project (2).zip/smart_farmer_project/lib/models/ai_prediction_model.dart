class AIPredictionResult {
  final String cropName;
  final String? variety;
  final String storageType;
  final double estimatedStorageDays;
  final double remainingStorageDays;
  final String spoilageRisk; // 'Low Risk', 'Medium Risk', 'High Risk'
  final String recommendedTemp;
  final String recommendedHumidity;
  final String recommendedConditions;
  final bool coldStorageAdvised;
  final List<String> handlingInstructions;
  final List<String> warnings;
  final String explanation;
  final DateTime calculationDate;

  AIPredictionResult({
    required this.cropName,
    this.variety,
    required this.storageType,
    required this.estimatedStorageDays,
    required this.remainingStorageDays,
    required this.spoilageRisk,
    required this.recommendedTemp,
    required this.recommendedHumidity,
    required this.recommendedConditions,
    required this.coldStorageAdvised,
    required this.handlingInstructions,
    required this.warnings,
    required this.explanation,
    DateTime? calculationDate,
  }) : calculationDate = calculationDate ?? DateTime.now();
}
