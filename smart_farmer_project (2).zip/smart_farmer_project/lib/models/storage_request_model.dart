class StorageRequestModel {
  final String requestId;
  final String farmerId;
  final String farmerName;
  final String farmerContact;
  final String warehouseId;
  final String warehouseOwnerId;
  final String warehouseName;
  final String cropName;
  final double quantity;
  final String unit;
  final int durationMonths;
  final String preferredStorageType;
  final String? additionalNotes;
  final String status; // 'Pending', 'Accepted', 'Rejected', 'Completed', 'Cancelled'
  final DateTime createdAt;
  final DateTime? updatedAt;

  StorageRequestModel({
    required this.requestId,
    required this.farmerId,
    required this.farmerName,
    required this.farmerContact,
    required this.warehouseId,
    required this.warehouseOwnerId,
    required this.warehouseName,
    required this.cropName,
    required this.quantity,
    required this.unit,
    required this.durationMonths,
    required this.preferredStorageType,
    this.additionalNotes,
    this.status = 'Pending',
    DateTime? createdAt,
    this.updatedAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'requestId': requestId,
      'farmerId': farmerId,
      'farmerName': farmerName,
      'farmerContact': farmerContact,
      'warehouseId': warehouseId,
      'warehouseOwnerId': warehouseOwnerId,
      'warehouseName': warehouseName,
      'cropName': cropName,
      'quantity': quantity,
      'unit': unit,
      'durationMonths': durationMonths,
      'preferredStorageType': preferredStorageType,
      'additionalNotes': additionalNotes,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  factory StorageRequestModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return StorageRequestModel(
      requestId: id ?? map['requestId'] ?? '',
      farmerId: map['farmerId'] ?? '',
      farmerName: map['farmerName'] ?? '',
      farmerContact: map['farmerContact'] ?? '',
      warehouseId: map['warehouseId'] ?? '',
      warehouseOwnerId: map['warehouseOwnerId'] ?? '',
      warehouseName: map['warehouseName'] ?? '',
      cropName: map['cropName'] ?? '',
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0.0,
      unit: map['unit'] ?? 'Quintals (q)',
      durationMonths: (map['durationMonths'] as num?)?.toInt() ?? 1,
      preferredStorageType: map['preferredStorageType'] ?? 'Cold Storage',
      additionalNotes: map['additionalNotes'],
      status: map['status'] ?? 'Pending',
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : null,
    );
  }

  StorageRequestModel copyWith({
    String? status,
    DateTime? updatedAt,
  }) {
    return StorageRequestModel(
      requestId: requestId,
      farmerId: farmerId,
      farmerName: farmerName,
      farmerContact: farmerContact,
      warehouseId: warehouseId,
      warehouseOwnerId: warehouseOwnerId,
      warehouseName: warehouseName,
      cropName: cropName,
      quantity: quantity,
      unit: unit,
      durationMonths: durationMonths,
      preferredStorageType: preferredStorageType,
      additionalNotes: additionalNotes,
      status: status ?? this.status,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }
}
