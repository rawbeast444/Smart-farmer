class WarehouseModel {
  final String warehouseId;
  final String ownerId;
  final String warehouseName;
  final String ownerName;
  final String address;
  final String district;
  final String state;
  final double totalCapacity; // in quintals
  final double availableCapacity; // in quintals
  final String storageType; // Cold Storage, Normal, CA, Dry
  final double storageCharges; // ₹ per quintal per month
  final String contactNumber;
  final String? operationalStatus; // 'Operational', 'Under Maintenance'
  final String? temperatureRange; // e.g., '0°C to 4°C'
  final double distanceKm;
  final List<String> images;
  final DateTime createdAt;
  final DateTime updatedAt;

  WarehouseModel({
    required this.warehouseId,
    required this.ownerId,
    required this.warehouseName,
    required this.ownerName,
    required this.address,
    required this.district,
    required this.state,
    required this.totalCapacity,
    required this.availableCapacity,
    required this.storageType,
    required this.storageCharges,
    required this.contactNumber,
    this.operationalStatus = 'Operational',
    this.temperatureRange,
    this.distanceKm = 12.0,
    this.images = const [],
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  double get occupiedCapacity => totalCapacity - availableCapacity;
  double get occupancyPercentage => totalCapacity > 0 ? (occupiedCapacity / totalCapacity) * 100 : 0;
  bool get hasSpace => availableCapacity > 0;

  Map<String, dynamic> toMap() {
    return {
      'warehouseId': warehouseId,
      'ownerId': ownerId,
      'warehouseName': warehouseName,
      'ownerName': ownerName,
      'address': address,
      'district': district,
      'state': state,
      'totalCapacity': totalCapacity,
      'availableCapacity': availableCapacity,
      'storageType': storageType,
      'storageCharges': storageCharges,
      'contactNumber': contactNumber,
      'operationalStatus': operationalStatus,
      'temperatureRange': temperatureRange,
      'distanceKm': distanceKm,
      'images': images,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory WarehouseModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return WarehouseModel(
      warehouseId: id ?? map['warehouseId'] ?? '',
      ownerId: map['ownerId'] ?? '',
      warehouseName: map['warehouseName'] ?? '',
      ownerName: map['ownerName'] ?? '',
      address: map['address'] ?? '',
      district: map['district'] ?? 'Sangli',
      state: map['state'] ?? 'Maharashtra',
      totalCapacity: (map['totalCapacity'] as num?)?.toDouble() ?? 0.0,
      availableCapacity: (map['availableCapacity'] as num?)?.toDouble() ?? 0.0,
      storageType: map['storageType'] ?? 'Normal Storage',
      storageCharges: (map['storageCharges'] as num?)?.toDouble() ?? 0.0,
      contactNumber: map['contactNumber'] ?? '',
      operationalStatus: map['operationalStatus'] ?? 'Operational',
      temperatureRange: map['temperatureRange'],
      distanceKm: (map['distanceKm'] as num?)?.toDouble() ?? 10.0,
      images: List<String>.from(map['images'] ?? []),
      createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : DateTime.now(),
      updatedAt: map['updatedAt'] != null ? DateTime.parse(map['updatedAt']) : DateTime.now(),
    );
  }

  WarehouseModel copyWith({
    String? warehouseName,
    String? ownerName,
    String? address,
    String? district,
    String? state,
    double? totalCapacity,
    double? availableCapacity,
    String? storageType,
    double? storageCharges,
    String? contactNumber,
    String? operationalStatus,
    String? temperatureRange,
    double? distanceKm,
    List<String>? images,
  }) {
    return WarehouseModel(
      warehouseId: warehouseId,
      ownerId: ownerId,
      warehouseName: warehouseName ?? this.warehouseName,
      ownerName: ownerName ?? this.ownerName,
      address: address ?? this.address,
      district: district ?? this.district,
      state: state ?? this.state,
      totalCapacity: totalCapacity ?? this.totalCapacity,
      availableCapacity: availableCapacity ?? this.availableCapacity,
      storageType: storageType ?? this.storageType,
      storageCharges: storageCharges ?? this.storageCharges,
      contactNumber: contactNumber ?? this.contactNumber,
      operationalStatus: operationalStatus ?? this.operationalStatus,
      temperatureRange: temperatureRange ?? this.temperatureRange,
      distanceKm: distanceKm ?? this.distanceKm,
      images: images ?? this.images,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
