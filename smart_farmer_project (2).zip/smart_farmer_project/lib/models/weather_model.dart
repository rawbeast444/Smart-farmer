class WeatherModel {
  final String location;
  final double temperature; // Celsius
  final String condition; // 'Sunny', 'Partly Cloudy', 'Rainy', etc.
  final int humidity; // %
  final double rainfallForecastMm;
  final double windSpeedKmh;
  final String? weatherAlert;
  final List<DailyForecast> forecast;
  final List<String> agricultureAdvice;
  final bool isDemo;

  WeatherModel({
    required this.location,
    required this.temperature,
    required this.condition,
    required this.humidity,
    required this.rainfallForecastMm,
    required this.windSpeedKmh,
    this.weatherAlert,
    required this.forecast,
    required this.agricultureAdvice,
    this.isDemo = true,
  });
}

class DailyForecast {
  final String dayName;
  final double tempMax;
  final double tempMin;
  final String condition;
  final int rainProbability;

  DailyForecast({
    required this.dayName,
    required this.tempMax,
    required this.tempMin,
    required this.condition,
    required this.rainProbability,
  });
}
