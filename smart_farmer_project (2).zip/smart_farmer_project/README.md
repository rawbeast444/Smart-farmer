# Smart Farmer – AI Agriculture Assistant
> **"Smart Decisions. Better Harvests."**  
> Complete Android Application for Indian Farmers and Warehouse Owners.

---

## 🌾 Overview
**Smart Farmer** is a comprehensive, production-architected Android mobile application developed in Flutter and Dart, built specifically to empower Indian farmers after harvesting. It bridges the critical gap between:
**FARMERS ➔ CROPS ➔ APMC MARKETS ➔ WAREHOUSES & COLD STORES ➔ AI STORAGE PREDICTION**

The platform helps farmers determine whether to sell immediately or store their produce, calculating true net returns after freight costs across regional mandis, discovering certified local cold storages, and forecasting crop storage life using transparent post-harvest rules.

---

## 🚀 Key Features

### 1. Dual Role-Based Architecture
* **Farmer Role**:
  * Farmer profile & harvest inventory management.
  * APMC market price discovery & multi-mandi comparison matrix.
  * Real-time net return calculator ($$Net\,Value = Gross\,Revenue - Transport\,Cost$$).
  * Nearby certified warehouse discovery (Cold Storage, Normal, CA, Dry Storage).
  * Direct storage enquiry dispatch & status tracking.
  * Transparent Agricultural AI crop shelf-life & spoilage risk prediction.
  * Agriculture-focused weather forecasts & harvesting advisories.
* **Warehouse Owner Role**:
  * Dedicated enterprise console & capacity management.
  * Live storage occupancy tracking ($$Occupied = Total - Available$$).
  * Rate card management (₹/quintal/month).
  * Farmer enquiry review, acceptance, and automated capacity deduction.

### 2. Market Recommendation Engine
* Evaluates price per quintal against rural transport freight rates ($$₹2.50/q/km$$) and handling fees.
* Explains *why* a specific mandi is recommended (e.g., higher price offsets additional transit distance).

### 3. AI Crop Storage Assistant
* Backed by Indian Council of Agricultural Research (ICAR) & National Horticulture Board (NHB) benchmarks.
* Factors in crop variety, physical condition (damage/freshness), harvest date, storage type, temperature, and packaging aerations.
* Yields remaining storage days, spoilage risk classification (Low/Medium/High), cold storage advice, and post-harvest handling guidelines.

### 4. Demo Mode & Live Fallback Architecture
* Clearly labelled **DEMO DATA** banners.
* Pre-configured realistic datasets for Maharashtra agricultural hubs: **Sangli, Kolhapur, Pune, Nashik, Satara, Solapur**.
* One-tap quick demo login for **Rahul Patil (Farmer)** and **Suresh Shinde (Warehouse Owner)**.

---

## 🛠️ Technology Stack
* **Framework**: Flutter 3.x (Null-safe Dart)
* **Design System**: Material Design 3 with custom Agricultural Color Palette:
  * Primary: Deep Agriculture Green (`#1B5E20`)
  * Secondary: Fresh Green (`#4CAF50`)
  * Accent: Light Green (`#A5D6A7`)
  * Background: Off White (`#F8FAF5`)
  * Surface: Pure White (`#FFFFFF`)
* **State Management**: Provider / ChangeNotifier Clean Architecture
* **Backend Ready**: Firebase Authentication, Cloud Firestore, Firebase Storage, FCM architecture ready
* **Target Platforms**: Android 8.0+ (API Level 26 to 34)

---

## 📂 Project Structure
```
smart_farmer/
├── android/                   # Native Android manifests, permissions & Gradle configs
├── assets/                    # Image & icon resources
├── firestore.rules            # Production-grade Firestore security rules
├── firestore.indexes.json     # Compound query composite indexes
├── pubspec.yaml               # Flutter package dependencies
├── README.md                  # Complete documentation
└── lib/
    ├── main.dart              # Application entrypoint
    ├── app.dart               # MultiProvider root app widget
    ├── core/
    │   ├── constants/         # Colors, strings, constants & conversion rates
    │   ├── routing/           # Complete AppRouter for 28+ screens
    │   ├── services/          # API interfaces (AGMARKNET, Weather, Map, AI)
    │   ├── theme/             # Material 3 agricultural theme
    │   └── utils/             # Calculations, Indian currency formatters & validators
    ├── data/
    │   ├── datasources/       # Realistic Maharashtra demo data
    │   └── repositories/      # Auth, Crop, Market, Warehouse, Weather repositories
    ├── models/                # User, Crop, MarketPrice, Warehouse, StorageRequest models
    ├── shared/widgets/        # Cards, AppBars, DemoBanner, Buttons, State widgets
    ├── state/                 # AuthState, CropState, MarketState, WarehouseState
    └── features/
        ├── auth/              # Role selection, Login, Register, Forgot Password
        ├── onboarding/        # Splash screen & 3-step onboarding flow
        ├── farmer/            # Farmer dashboard, Crops, Markets, Warehouses, AI, Weather
        ├── warehouse_owner/   # Owner dashboard, Capacity management, Enquiries
        ├── notifications/     # Real-time alert notifications
        └── settings/          # Language preferences, FAQ, Terms & Privacy
```

---

## 🔐 Firebase Setup Instructions

1. **Create Firebase Project**:
   * Navigate to [Firebase Console](https://console.firebase.google.com/) and create a new project named `smart-farmer-app`.
2. **Add Android App**:
   * Register Android package: `com.agritech.smartfarmer`.
   * Download `google-services.json` and place it in `smart_farmer/android/app/`.
3. **Deploy Security Rules**:
   * Deploy the included `firestore.rules` file:
     ```bash
     firebase deploy --only firestore:rules
     ```
   * Deploy the compound indexes:
     ```bash
     firebase deploy --only firestore:indexes
     ```
4. **Enable Firebase Authentication**:
   * Enable **Email/Password** authentication provider.

---

## 🌐 External API Integration Guide

### 1. AGMARKNET / e-NAM Integration
Replace `AgmarknetApiService` in `lib/core/services/market_api_service.dart`:
```dart
// Endpoint: https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070
// Params: api-key, format=json, filters[state]=Maharashtra
```

### 2. OpenWeatherMap API
Provide API key in `lib/core/services/weather_api_service.dart`:
```dart
final weatherService = OpenWeatherMapService(apiKey: 'YOUR_OPENWEATHERMAP_API_KEY', isLive: true);
```

### 3. Google Maps Flutter Integration
Add your Google Maps Android API key inside `smart_farmer/android/app/src/main/AndroidManifest.xml`:
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_ACTUAL_API_KEY_HERE"/>
```

---

## 📱 Android Build Instructions

### Prerequisites
* Flutter SDK >= 3.0.0
* Android Studio / Android SDK (API Level 34)
* Java JDK 17

### 1. Fetch Dependencies
```bash
cd smart_farmer
flutter pub get
```

### 2. Run Debug Build on Device / Emulator
```bash
flutter run
```

### 3. Build Production Release APK
```bash
flutter build apk --release
```
The compiled APK will be generated at:
`smart_farmer/build/app/outputs/flutter-apk/app-release.apk`

---

## 🧪 Testing & Validation Checklist
- [x] Full role-switching between Farmer and Warehouse Owner without data leakage.
- [x] Net revenue algorithm accurately subtracts transport cost ($$Gross - Freight$$).
- [x] Multi-market comparison table properly formats quintal/kg conversions.
- [x] Warehouse available capacity strictly prevented from becoming negative or exceeding total capacity.
- [x] Post-harvest AI rules accurately reflect temperature sensitivity for perishable crops (Tomato) vs durable grains (Wheat/Rice).
