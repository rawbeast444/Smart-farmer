package com.agritech.smartfarmer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()