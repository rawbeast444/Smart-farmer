import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_strings.dart';
import '../../../shared/widgets/cards.dart';
import '../../../shared/widgets/demo_banner_widget.dart';
import '../../../shared/widgets/ui_states.dart';
import '../../../state/market_state.dart';

class MarketSearchScreen extends StatefulWidget {
  final String? initialQuery;

  const MarketSearchScreen({Key? key, this.initialQuery}) : super(key: key);

  @override
  State<MarketSearchScreen> createState() => _MarketSearchScreenState();
}

class _MarketSearchScreenState extends State<MarketSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedCrop = 'All';
  String _selectedDistrict = 'All';
  String _sortBy = 'Nearest Market';

  @override
  void initState() {
    super.initState();
    if (widget.initialQuery != null) {
      _searchController.text = widget.initialQuery!;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MarketState>().loadMarkets(query: widget.initialQuery);
    });
  }

  void _applyFilters() {
    context.read<MarketState>().loadMarkets(
      crop: _selectedCrop,
      district: _selectedDistrict,
      sortBy: _sortBy,
      query: _searchController.text.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final marketState = context.watch<MarketState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Agricultural Mandi Markets'),
        actions: [
          IconButton(
            icon: const Icon(Icons.map_outlined),
            tooltip: 'View Map',
            onPressed: () => Navigator.pushNamed(context, '/market_map'),
          ),
        ],
      ),
      body: Column(
        children: [
          const DemoBannerWidget(text: AppStrings.demoBadge),

          // Search & Filter Header
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  onChanged: (val) => _applyFilters(),
                  decoration: InputDecoration(
                    hintText: 'Search by mandi, city or crop...',
                    prefixIcon: const Icon(Icons.search, color: AppColors.primary),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              _applyFilters();
                            },
                          )
                        : null,
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
                const SizedBox(height: 10),
                // Horizontal filter chips
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      // Crop Filter
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedCrop,
                          underline: const SizedBox(),
                          icon: const Icon(Icons.arrow_drop_down, color: AppColors.primary),
                          items: ['All', ...AppConstants.supportedCrops]
                              .map((c) => DropdownMenuItem(value: c, child: Text('Crop: $c', style: const TextStyle(fontSize: 12))))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedCrop = val);
                              _applyFilters();
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 8),

                      // District Filter
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedDistrict,
                          underline: const SizedBox(),
                          icon: const Icon(Icons.arrow_drop_down, color: AppColors.primary),
                          items: ['All', ...AppConstants.maharashtraDistricts]
                              .map((d) => DropdownMenuItem(value: d, child: Text('District: $d', style: const TextStyle(fontSize: 12))))
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedDistrict = val);
                              _applyFilters();
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Sort Filter
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: _sortBy,
                          underline: const SizedBox(),
                          icon: const Icon(Icons.sort, color: AppColors.primary, size: 18),
                          items: [
                            'Nearest Market',
                            'Highest Average Price',
                            'Lowest Transportation Cost',
                            'Highest Demand',
                            'Latest Update',
                          ].map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 12)))).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _sortBy = val);
                              _applyFilters();
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Market List
          Expanded(
            child: marketState.isLoading
                ? const LoadingWidget(message: 'Fetching mandi prices...')
                : marketState.markets.isEmpty
                    ? const EmptyStateWidget(
                        title: 'No Markets Found',
                        description: 'Try adjusting your crop or district filters to discover more agricultural mandis.',
                        icon: Icons.storefront_outlined,
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(14),
                        itemCount: marketState.markets.length,
                        itemBuilder: (context, index) {
                          final market = marketState.markets[index];
                          final isSelected = marketState.selectedMarketsForComparison
                              .any((m) => m.marketId == market.marketId);

                          return MarketPriceCard(
                            market: market,
                            isSelected: isSelected,
                            onSelectionChanged: () {
                              marketState.toggleComparisonSelection(market);
                            },
                            onTap: () => Navigator.pushNamed(context, '/market_details', arguments: market),
                          );
                        },
                      ),
          ),
        ],
      ),
      bottomNavigationBar: marketState.selectedMarketsForComparison.length >= 2
          ? Container(
              padding: const EdgeInsets.all(16),
              color: AppColors.surface,
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8, offset: const Offset(0, -2))
              ],
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${marketState.selectedMarketsForComparison.length} Markets Selected',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        const Text('Ready for Net Value Comparison', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(
                        context,
                        '/market_comparison',
                        arguments: marketState.selectedMarketsForComparison,
                      );
                    },
                    icon: const Icon(Icons.compare_arrows),
                    label: const Text('Compare Now'),
                  ),
                ],
              ),
            )
          : null,
    );
  }
}
